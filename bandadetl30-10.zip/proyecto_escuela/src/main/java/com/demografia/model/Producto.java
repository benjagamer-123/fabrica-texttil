package com.demografia.model;

public class Producto {
    private int id_producto;
    private String codigo;
    private String nombre;
    private String descripcion;
    private String unidad_medida;
    private String tipo;
    private int id_categoria;

    public Producto() {}
    public Producto(int id_producto, String codigo, String nombre, String descripcion, String unidad_medida, String tipo, int id_categoria) {
        this.id_producto = id_producto;
        this.codigo = codigo;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.unidad_medida = unidad_medida;
        this.tipo = tipo;
        this.id_categoria = id_categoria;
    }
    
    public Producto( String codigo, String nombre, String descripcion, String unidad_medida, String tipo, int id_categoria) {
    
        this.codigo = codigo;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.unidad_medida = unidad_medida;
        this.tipo = tipo;
        this.id_categoria = id_categoria;
    }

    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getUnidad_medida() { return unidad_medida; }
    public void setUnidad_medida(String unidad_medida) { this.unidad_medida = unidad_medida; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public int getId_categoria() { return id_categoria; }
    public void setId_categoria(int id_categoria) { this.id_categoria = id_categoria; }
}
