package com.demografia.model;

public class ConsumoMateriaPrima {
    private int id_consumo;
    private int id_etapa;
    private int id_materia_prima;
    private double cantidad_utilizada;
    private String fecha_consumo;
    private String lote;

    public ConsumoMateriaPrima() {}
    public ConsumoMateriaPrima(int id_consumo, int id_etapa, int id_materia_prima, double cantidad_utilizada, String fecha_consumo, String lote) {
        this.id_consumo = id_consumo;
        this.id_etapa = id_etapa;
        this.id_materia_prima = id_materia_prima;
        this.cantidad_utilizada = cantidad_utilizada;
        this.fecha_consumo = fecha_consumo;
        this.lote = lote;
    }
    
    public ConsumoMateriaPrima( double cantidad_utilizada, String fecha_consumo, String lote) {
      
        this.cantidad_utilizada = cantidad_utilizada;
        this.fecha_consumo = fecha_consumo;
        this.lote = lote;
    }

    public int getId_consumo() { return id_consumo; }
    public void setId_consumo(int id_consumo) { this.id_consumo = id_consumo; }
    public int getId_etapa() { return id_etapa; }
    public void setId_etapa(int id_etapa) { this.id_etapa = id_etapa; }
    public int getId_materia_prima() { return id_materia_prima; }
    public void setId_materia_prima(int id_materia_prima) { this.id_materia_prima = id_materia_prima; }
    public double getCantidad_utilizada() { return cantidad_utilizada; }
    public void setCantidad_utilizada(double cantidad_utilizada) { this.cantidad_utilizada = cantidad_utilizada; }
    public String getFecha_consumo() { return fecha_consumo; }
    public void setFecha_consumo(String fecha_consumo) { this.fecha_consumo = fecha_consumo; }
    public String getLote() { return lote; }
    public void setLote(String lote) { this.lote = lote; }
}
