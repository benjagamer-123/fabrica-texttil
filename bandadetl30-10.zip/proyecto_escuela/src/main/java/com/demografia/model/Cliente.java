package com.demografia.model;

public class Cliente {
    private int id_cliente;
    private String razon_social;
    private String cuit;
    private String tipo_cliente;
    private String email;
    private String telefono;
    private String direccion;
    private String ciudad;
    private int id_pais;
    private String estado;

    public Cliente() {}
    public Cliente(int id_cliente, String razon_social, String cuit, String tipo_cliente, String email, String telefono, String direccion, String ciudad, int id_pais, String estado) {
        this.id_cliente = id_cliente;
        this.razon_social = razon_social;
        this.cuit = cuit;
        this.tipo_cliente = tipo_cliente;
        this.email = email;
        this.telefono = telefono;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.id_pais = id_pais;
        this.estado = estado;
    }
    
    public Cliente( String razon_social, String cuit, String tipo_cliente, String email, String telefono, String direccion, String ciudad, int id_pais, String estado) {
     
        this.razon_social = razon_social;
        this.cuit = cuit;
        this.tipo_cliente = tipo_cliente;
        this.email = email;
        this.telefono = telefono;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.id_pais = id_pais;
        this.estado = estado;
    }

    public int getId_cliente() { return id_cliente; }
    public void setId_cliente(int id_cliente) { this.id_cliente = id_cliente; }
    public String getRazon_social() { return razon_social; }
    public void setRazon_social(String razon_social) { this.razon_social = razon_social; }
    public String getCuit() { return cuit; }
    public void setCuit(String cuit) { this.cuit = cuit; }
    public String getTipo_cliente() { return tipo_cliente; }
    public void setTipo_cliente(String tipo_cliente) { this.tipo_cliente = tipo_cliente; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }
    public int getId_pais() { return id_pais; }
    public void setId_pais(int id_pais) { this.id_pais = id_pais; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
