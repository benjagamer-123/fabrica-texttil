package com.demografia.model;

public class EtapaProduccion {
    private int id_etapa;
    private int id_orden_prod;
    private String nombre_etapa;
    private int orden_secuencia;
    private String estado;
    private String fecha_inicio_real;
    private String fecha_fin_real;

    public EtapaProduccion() {}
    public EtapaProduccion(int id_etapa, int id_orden_prod, String nombre_etapa, int orden_secuencia, String estado, String fecha_inicio_real, String fecha_fin_real) {
        this.id_etapa = id_etapa;
        this.id_orden_prod = id_orden_prod;
        this.nombre_etapa = nombre_etapa;
        this.orden_secuencia = orden_secuencia;
        this.estado = estado;
        this.fecha_inicio_real = fecha_inicio_real;
        this.fecha_fin_real = fecha_fin_real;
    }
    
    public EtapaProduccion( String nombre_etapa, int orden_secuencia, String estado, String fecha_inicio_real, String fecha_fin_real) {
       
        this.nombre_etapa = nombre_etapa;
        this.orden_secuencia = orden_secuencia;
        this.estado = estado;
        this.fecha_inicio_real = fecha_inicio_real;
        this.fecha_fin_real = fecha_fin_real;
    }

    public int getId_etapa() { return id_etapa; }
    public void setId_etapa(int id_etapa) { this.id_etapa = id_etapa; }
    public int getId_orden_prod() { return id_orden_prod; }
    public void setId_orden_prod(int id_orden_prod) { this.id_orden_prod = id_orden_prod; }
    public String getNombre_etapa() { return nombre_etapa; }
    public void setNombre_etapa(String nombre_etapa) { this.nombre_etapa = nombre_etapa; }
    public int getOrden_secuencia() { return orden_secuencia; }
    public void setOrden_secuencia(int orden_secuencia) { this.orden_secuencia = orden_secuencia; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getFecha_inicio_real() { return fecha_inicio_real; }
    public void setFecha_inicio_real(String fecha_inicio_real) { this.fecha_inicio_real = fecha_inicio_real; }
    public String getFecha_fin_real() { return fecha_fin_real; }
    public void setFecha_fin_real(String fecha_fin_real) { this.fecha_fin_real = fecha_fin_real; }
}
