package com.demografia.model;

public class DetalleOrdenProd {
    private int id_detalle_orden_prod;
    private int id_orden_prod;
    private int id_producto;
    private double cantidad_plan;
    private double tiempo_unitario_est;
    private double tiempo_total_est;

    public DetalleOrdenProd() {}
    public DetalleOrdenProd(int id_detalle_orden_prod, int id_orden_prod, int id_producto, double cantidad_plan, double tiempo_unitario_est, double tiempo_total_est) {
        this.id_detalle_orden_prod = id_detalle_orden_prod;
        this.id_orden_prod = id_orden_prod;
        this.id_producto = id_producto;
        this.cantidad_plan = cantidad_plan;
        this.tiempo_unitario_est = tiempo_unitario_est;
        this.tiempo_total_est = tiempo_total_est;
    }
    
    public DetalleOrdenProd( double cantidad_plan, double tiempo_unitario_est, double tiempo_total_est) {
       
        this.cantidad_plan = cantidad_plan;
        this.tiempo_unitario_est = tiempo_unitario_est;
        this.tiempo_total_est = tiempo_total_est;
    }

    public int getId_detalle_orden_prod() { return id_detalle_orden_prod; }
    public void setId_detalle_orden_prod(int id_detalle_orden_prod) { this.id_detalle_orden_prod = id_detalle_orden_prod; }
    public int getId_orden_prod() { return id_orden_prod; }
    public void setId_orden_prod(int id_orden_prod) { this.id_orden_prod = id_orden_prod; }
    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }
    public double getCantidad_plan() { return cantidad_plan; }
    public void setCantidad_plan(double cantidad_plan) { this.cantidad_plan = cantidad_plan; }
    public double getTiempo_unitario_est() { return tiempo_unitario_est; }
    public void setTiempo_unitario_est(double tiempo_unitario_est) { this.tiempo_unitario_est = tiempo_unitario_est; }
    public double getTiempo_total_est() { return tiempo_total_est; }
    public void setTiempo_total_est(double tiempo_total_est) { this.tiempo_total_est = tiempo_total_est; }
}
