package com.demografia.model;

public class RedRelacion {

    private Integer idRed;
    private Rol rolPadre; // Relación FK con la clase Rol
    private Rol rolHijo;  // Relación FK con la clase Rol

    public RedRelacion() {
    }

    public RedRelacion(Integer idRed, Rol rolPadre, Rol rolHijo) {
        this.idRed = idRed;
        this.rolPadre = rolPadre;
        this.rolHijo = rolHijo;
    }
    
    public RedRelacion( Rol rolPadre, Rol rolHijo) {
      
        this.rolPadre = rolPadre;
        this.rolHijo = rolHijo;
    }

    public Integer getIdRed() {
        return idRed;
    }

    public void setIdRed(Integer idRed) {
        this.idRed = idRed;
    }

    public Rol getRolPadre() {
        return rolPadre;
    }

    public void setRolPadre(Rol rolPadre) {
        this.rolPadre = rolPadre;
    }

    public Rol getRolHijo() {
        return rolHijo;
    }

    public void setRolHijo(Rol rolHijo) {
        this.rolHijo = rolHijo;
    }
}
