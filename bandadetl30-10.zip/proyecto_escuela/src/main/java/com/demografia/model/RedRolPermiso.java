package com.demografia.model;

public class RedRolPermiso {

    private Integer idRedRolPermiso;
    private Rol rol;         // Relación FK con la clase Rol
    private Permiso permiso; // Relación FK con la clase Permiso

    public RedRolPermiso() {
    }

    public RedRolPermiso(Integer idRedRolPermiso, Rol rol, Permiso permiso) {
        this.idRedRolPermiso = idRedRolPermiso;
        this.rol = rol;
        this.permiso = permiso;
    }
    
    public RedRolPermiso( Rol rol, Permiso permiso) {
        this.rol = rol;
        this.permiso = permiso;
    }

    public Integer getIdRedRolPermiso() {
        return idRedRolPermiso;
    }

    public void setIdRedRolPermiso(Integer idRedRolPermiso) {
        this.idRedRolPermiso = idRedRolPermiso;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    public Permiso getPermiso() {
        return permiso;
    }

    public void setPermiso(Permiso permiso) {
        this.permiso = permiso;
    }
}
