package com.demografia.model;

public class Rol {
    private int id_rol;
    private String nombre;
    private String descripcion;

    // 1. Constructor vacío
    public Rol() {}

    // 2. Constructor solo con los IDs
    public Rol(int id_rol) {
        this.id_rol = id_rol;
    }

    // 3. Constructor sin ningún ID
    public Rol(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    // Getters y Setters
    public int getId_rol() { return id_rol; }
    public void setId_rol(int id_rol) { this.id_rol = id_rol; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}