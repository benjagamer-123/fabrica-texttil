package com.demografia.model;

public class OrdenCompra {
    private int id_orden_compra;
    private String fecha_orden;
    private String estado;
    private int id_proveedor;
    private double total_estimado;

    public OrdenCompra() {}
    public OrdenCompra(int id_orden_compra, String fecha_orden, String estado, int id_proveedor, double total_estimado) {
        this.id_orden_compra = id_orden_compra;
        this.fecha_orden = fecha_orden;
        this.estado = estado;
        this.id_proveedor = id_proveedor;
        this.total_estimado = total_estimado;
    }
    
    public OrdenCompra( String fecha_orden, String estado, int id_proveedor, double total_estimado) {
    
        this.fecha_orden = fecha_orden;
        this.estado = estado;
        this.id_proveedor = id_proveedor;
        this.total_estimado = total_estimado;
    }

    public int getId_orden_compra() { return id_orden_compra; }
    public void setId_orden_compra(int id_orden_compra) { this.id_orden_compra = id_orden_compra; }
    public String getFecha_orden() { return fecha_orden; }
    public void setFecha_orden(String fecha_orden) { this.fecha_orden = fecha_orden; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public int getId_proveedor() { return id_proveedor; }
    public void setId_proveedor(int id_proveedor) { this.id_proveedor = id_proveedor; }
    public double getTotal_estimado() { return total_estimado; }
    public void setTotal_estimado(double total_estimado) { this.total_estimado = total_estimado; }
}
