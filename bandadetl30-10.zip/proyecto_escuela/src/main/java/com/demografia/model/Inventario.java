package com.demografia.model;

public class Inventario {
    private int id_inventario;
    private int id_producto;
    private int id_deposito;
    private String lote;
    private double cantidad_disponible;
    private String unidad_medida;
    private String fecha_actualizacion;

    public Inventario() {}
    public Inventario(int id_inventario, int id_producto, int id_deposito, String lote, double cantidad_disponible, String unidad_medida, String fecha_actualizacion) {
        this.id_inventario = id_inventario;
        this.id_producto = id_producto;
        this.id_deposito = id_deposito;
        this.lote = lote;
        this.cantidad_disponible = cantidad_disponible;
        this.unidad_medida = unidad_medida;
        this.fecha_actualizacion = fecha_actualizacion;
    }
    
    public Inventario ( String lote, double cantidad_disponible, String unidad_medida, String fecha_actualizacion) {
     
        this.lote = lote;
        this.cantidad_disponible = cantidad_disponible;
        this.unidad_medida = unidad_medida;
        this.fecha_actualizacion = fecha_actualizacion;
    }

    public int getId_inventario() { return id_inventario; }
    public void setId_inventario(int id_inventario) { this.id_inventario = id_inventario; }
    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }
    public int getId_deposito() { return id_deposito; }
    public void setId_deposito(int id_deposito) { this.id_deposito = id_deposito; }
    public String getLote() { return lote; }
    public void setLote(String lote) { this.lote = lote; }
    public double getCantidad_disponible() { return cantidad_disponible; }
    public void setCantidad_disponible(double cantidad_disponible) { this.cantidad_disponible = cantidad_disponible; }
    public String getUnidad_medida() { return unidad_medida; }
    public void setUnidad_medida(String unidad_medida) { this.unidad_medida = unidad_medida; }
    public String getFecha_actualizacion() { return fecha_actualizacion; }
    public void setFecha_actualizacion(String fecha_actualizacion) { this.fecha_actualizacion = fecha_actualizacion; }
}
