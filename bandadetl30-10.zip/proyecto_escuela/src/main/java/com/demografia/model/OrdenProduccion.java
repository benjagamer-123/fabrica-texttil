package com.demografia.model;

public class OrdenProduccion {
    private int id_orden_prod;
    private String numero_orden;
    private String fecha_inicio_est;
    private String fecha_fin_est;
    private String estado;
    private int id_responsable;
    private String observaciones;

    public OrdenProduccion() {}
    public OrdenProduccion(int id_orden_prod, String numero_orden, String fecha_inicio_est, String fecha_fin_est, String estado, int id_responsable, String observaciones) {
        this.id_orden_prod = id_orden_prod;
        this.numero_orden = numero_orden;
        this.fecha_inicio_est = fecha_inicio_est;
        this.fecha_fin_est = fecha_fin_est;
        this.estado = estado;
        this.id_responsable = id_responsable;
        this.observaciones = observaciones;
    }
    
    public OrdenProduccion( String numero_orden, String fecha_inicio_est, String fecha_fin_est, String estado, int id_responsable, String observaciones) {
       
        this.numero_orden = numero_orden;
        this.fecha_inicio_est = fecha_inicio_est;
        this.fecha_fin_est = fecha_fin_est;
        this.estado = estado;
        this.id_responsable = id_responsable;
        this.observaciones = observaciones;
    }

    public int getId_orden_prod() { return id_orden_prod; }
    public void setId_orden_prod(int id_orden_prod) { this.id_orden_prod = id_orden_prod; }
    public String getNumero_orden() { return numero_orden; }
    public void setNumero_orden(String numero_orden) { this.numero_orden = numero_orden; }
    public String getFecha_inicio_est() { return fecha_inicio_est; }
    public void setFecha_inicio_est(String fecha_inicio_est) { this.fecha_inicio_est = fecha_inicio_est; }
    public String getFecha_fin_est() { return fecha_fin_est; }
    public void setFecha_fin_est(String fecha_fin_est) { this.fecha_fin_est = fecha_fin_est; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public int getId_responsable() { return id_responsable; }
    public void setId_responsable(int id_responsable) { this.id_responsable = id_responsable; }
    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
}
