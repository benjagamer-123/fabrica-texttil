package com.demografia.model;

public class DetallePedido {
    private int id_detalle_pedido;
    private int id_pedido;
    private int id_producto;
    private double cantidad;
    private double precio_unitario;
    private double descuento;
    private double subtotal;

    public DetallePedido() {}
    public DetallePedido(int id_detalle_pedido, int id_pedido, int id_producto, double cantidad, double precio_unitario, double descuento, double subtotal) {
        this.id_detalle_pedido = id_detalle_pedido;
        this.id_pedido = id_pedido;
        this.id_producto = id_producto;
        this.cantidad = cantidad;
        this.precio_unitario = precio_unitario;
        this.descuento = descuento;
        this.subtotal = subtotal;
    }
    
    public DetallePedido( double cantidad, double precio_unitario, double descuento, double subtotal) {
       
        this.cantidad = cantidad;
        this.precio_unitario = precio_unitario;
        this.descuento = descuento;
        this.subtotal = subtotal;
    }
    
    public int getId_detalle_pedido() { return id_detalle_pedido; }
    public void setId_detalle_pedido(int id_detalle_pedido) { this.id_detalle_pedido = id_detalle_pedido; }
    public int getId_pedido() { return id_pedido; }
    public void setId_pedido(int id_pedido) { this.id_pedido = id_pedido; }
    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }
    public double getCantidad() { return cantidad; }
    public void setCantidad(double cantidad) { this.cantidad = cantidad; }
    public double getPrecio_unitario() { return precio_unitario; }
    public void setPrecio_unitario(double precio_unitario) { this.precio_unitario = precio_unitario; }
    public double getDescuento() { return descuento; }
    public void setDescuento(double descuento) { this.descuento = descuento; }
    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
}
