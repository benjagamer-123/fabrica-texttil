package com.demografia.model;

public class Permiso {

    private Integer idPermisos;
    private String nombre;
    private String descripcion;

    public Permiso() {
    }

    public Permiso(Integer idPermisos, String nombre, String descripcion) {
        this.idPermisos = idPermisos;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }
    
    public Permiso( String nombre, String descripcion) {
      
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public Integer getIdPermisos() {
        return idPermisos;
    }

    public void setIdPermisos(Integer idPermisos) {
        this.idPermisos = idPermisos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
