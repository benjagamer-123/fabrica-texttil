package com.demografia.model;

public class Pais {
    private int id_pais;
    private String nombre;
    private String codigo_iso;

    public Pais() {}
    public Pais(int id_pais, String nombre, String codigo_iso) {
        this.id_pais = id_pais;
        this.nombre = nombre;
        this.codigo_iso = codigo_iso;
    }
    
    public Pais( String nombre, String codigo_iso) {
       
        this.nombre = nombre;
        this.codigo_iso = codigo_iso;
    }

    public int getId_pais() { return id_pais; }
    public void setId_pais(int id_pais) { this.id_pais = id_pais; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getCodigo_iso() { return codigo_iso; }
    public void setCodigo_iso(String codigo_iso) { this.codigo_iso = codigo_iso; }
}
