package com.demografia.model;

import java.sql.Timestamp;

public class Auditoria {
    private int id_auditoria;
    private int id_usuario;
    private String tabla_afectada;
    private int id_registro;
    private String accion;
    private Timestamp fecha_hora;
    private String detalle_anterior;
    private String detalle_nuevo;
    private String ip_origen;

    public Auditoria() {}
    public Auditoria(int id_auditoria, int id_usuario, String tabla_afectada, int id_registro, String accion, Timestamp fecha_hora, String detalle_anterior, String detalle_nuevo, String ip_origen) {
        this.id_auditoria = id_auditoria;
        this.id_usuario = id_usuario;
        this.tabla_afectada = tabla_afectada;
        this.id_registro = id_registro;
        this.accion = accion;
        this.fecha_hora = fecha_hora;
        this.detalle_anterior = detalle_anterior;
        this.detalle_nuevo = detalle_nuevo;
        this.ip_origen = ip_origen;
    }
    
    public Auditoria ( String tabla_afectada, int id_registro, String accion, Timestamp fecha_hora, String detalle_anterior, String detalle_nuevo, String ip_origen) {
        this.tabla_afectada = tabla_afectada;
        this.accion = accion;
        this.fecha_hora = fecha_hora;
        this.detalle_anterior = detalle_anterior;
        this.detalle_nuevo = detalle_nuevo;
        this.ip_origen = ip_origen;
    }

    public int getId_auditoria() { return id_auditoria; }
    public void setId_auditoria(int id_auditoria) { this.id_auditoria = id_auditoria; }
    public int getId_usuario() { return id_usuario; }
    public void setId_usuario(int id_usuario) { this.id_usuario = id_usuario; }
    public String getTabla_affected() { return tabla_afectada; }
    public void setTabla_affected(String tabla_affected) { this.tabla_afectada = tabla_affected; }
    public int getId_registro() { return id_registro; }
    public void setId_registro(int id_registro) { this.id_registro = id_registro; }
    public String getAccion() { return accion; }
    public void setAccion(String accion) { this.accion = accion; }
    public Timestamp getFecha_hora() { return fecha_hora; }
    public void setFecha_hora(Timestamp timestamp) { this.fecha_hora = timestamp; }
    public String getDetalle_anterior() { return detalle_anterior; }
    public void setDetalle_anterior(String detalle_anterior) { this.detalle_anterior = detalle_anterior; }
    public String getDetalle_nuevo() { return detalle_nuevo; }
    public void setDetalle_nuevo(String detalle_nuevo) { this.detalle_nuevo = detalle_nuevo; }
    public String getIp_origen() { return ip_origen; }
    public void setIp_origen(String ip_origen) { this.ip_origen = ip_origen; }
}
