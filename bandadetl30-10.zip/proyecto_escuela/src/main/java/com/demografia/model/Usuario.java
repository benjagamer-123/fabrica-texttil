package com.demografia.model;

public class Usuario {
    private int id_usuario;
    private String nombre;
    private String email;
    private String password_hash;
    private String estado;
    private int id_rol;

    // 1. Constructor vacío
    public Usuario() {}

    // 2. Constructor solo con los IDs
    public Usuario(int id_usuario, int id_rol) {
        this.id_usuario = id_usuario;
        this.id_rol = id_rol;
    }

    // 3. Constructor sin ningún ID
    public Usuario(String nombre, String email, String password_hash, String estado) {
        this.nombre = nombre;
        this.email = email;
        this.password_hash = password_hash;
        this.estado = estado;
    }

    // Getters y Setters
    public int getId_usuario() { return id_usuario; }
    public void setId_usuario(int id_usuario) { this.id_usuario = id_usuario; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword_hash() { return password_hash; }
    public void setPassword_hash(String password_hash) { this.password_hash = password_hash; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public int getId_rol() { return id_rol; }
    public void setId_rol(int id_rol) { this.id_rol = id_rol; }
}