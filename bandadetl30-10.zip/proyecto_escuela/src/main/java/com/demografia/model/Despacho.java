package com.demografia.model;

public class Despacho {
    private int id_despacho;
    private String fecha_despacho;
    private int id_pedido;
    private String transportista;
    private String estado;

    public Despacho() {}
    public Despacho(int id_despacho, String fecha_despacho, int id_pedido, String transportista, String estado) {
        this.id_despacho = id_despacho;
        this.fecha_despacho = fecha_despacho;
        this.id_pedido = id_pedido;
        this.transportista = transportista;
        this.estado = estado;
    }
    
    public Despacho( String fecha_despacho, int id_pedido, String transportista, String estado) {
        
        this.fecha_despacho = fecha_despacho;
        this.id_pedido = id_pedido;
        this.transportista = transportista;
        this.estado = estado;
    }


    public int getId_despacho() { return id_despacho; }
    public void setId_despacho(int id_despacho) { this.id_despacho = id_despacho; }
    public String getFecha_despacho() { return fecha_despacho; }
    public void setFecha_despacho(String fecha_despacho) { this.fecha_despacho = fecha_despacho; }
    public int getId_pedido() { return id_pedido; }
    public void setId_pedido(int id_pedido) { this.id_pedido = id_pedido; }
    public String getTransportista() { return transportista; }
    public void setTransportista(String transportista) { this.transportista = transportista; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
