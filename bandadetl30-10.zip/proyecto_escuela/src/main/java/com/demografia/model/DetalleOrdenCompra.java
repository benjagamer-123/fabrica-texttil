package com.demografia.model;

public class DetalleOrdenCompra {
    private int id_detalle_compra;
    private int id_orden_compra;
    private int id_materia_prima;
    private double cantidad;
    private double precio_unitario;

    public DetalleOrdenCompra() {}
    public DetalleOrdenCompra(int id_detalle_compra, int id_orden_compra, int id_materia_prima, double cantidad, double precio_unitario) {
        this.id_detalle_compra = id_detalle_compra;
        this.id_orden_compra = id_orden_compra;
        this.id_materia_prima = id_materia_prima;
        this.cantidad = cantidad;
        this.precio_unitario = precio_unitario;
    }
    
    public DetalleOrdenCompra( double cantidad, double precio_unitario) {
    
        this.cantidad = cantidad;
        this.precio_unitario = precio_unitario;
    }

    public int getId_detalle_compra() { return id_detalle_compra; }
    public void setId_detalle_compra(int id_detalle_compra) { this.id_detalle_compra = id_detalle_compra; }
    public int getId_orden_compra() { return id_orden_compra; }
    public void setId_orden_compra(int id_orden_compra) { this.id_orden_compra = id_orden_compra; }
    public int getId_materia_prima() { return id_materia_prima; }
    public void setId_materia_prima(int id_materia_prima) { this.id_materia_prima = id_materia_prima; }
    public double getCantidad() { return cantidad; }
    public void setCantidad(double cantidad) { this.cantidad = cantidad; }
    public double getPrecio_unitario() { return precio_unitario; }
    public void setPrecio_unitario(double precio_unitario) { this.precio_unitario = precio_unitario; }
}
