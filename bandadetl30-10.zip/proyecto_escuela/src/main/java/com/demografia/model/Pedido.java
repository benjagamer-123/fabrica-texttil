package com.demografia.model;

public class Pedido {
    private int id_pedido;
    private int id_cliente;
    private String fecha_pedido;
    private String estado;
    private String fecha_entrega_req;
    private String observaciones;
    private double total_estimado;
    private Integer id_producto; // <--- Agregamos el campo id_producto

    public Pedido() {}

    public Pedido(int id_pedido, int id_cliente, String fecha_pedido, String estado, String fecha_entrega_req, String observaciones, double total_estimado, Integer id_producto) {
        this.id_pedido = id_pedido;
        this.id_cliente = id_cliente;
        this.fecha_pedido = fecha_pedido;
        this.estado = estado;
        this.fecha_entrega_req = fecha_entrega_req;
        this.observaciones = observaciones;
        this.total_estimado = total_estimado;
        this.id_producto = id_producto;
    }
    
    public Pedido( String fecha_pedido, String estado, String fecha_entrega_req, String observaciones, double total_estimado, Integer id_producto) {
       
        this.fecha_pedido = fecha_pedido;
        this.estado = estado;
        this.fecha_entrega_req = fecha_entrega_req;
        this.observaciones = observaciones;
        this.total_estimado = total_estimado;
        this.id_producto = id_producto;
    }

    public int getId_pedido() { return id_pedido; }
    public void setId_pedido(int id_pedido) { this.id_pedido = id_pedido; }

    public int getId_cliente() { return id_cliente; }
    public void setId_cliente(int id_cliente) { this.id_cliente = id_cliente; }

    public String getFecha_pedido() { return fecha_pedido; }
    public void setFecha_pedido(String fecha_pedido) { this.fecha_pedido = fecha_pedido; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getFecha_entrega_req() { return fecha_entrega_req; }
    public void setFecha_entrega_req(String fecha_entrega_req) { this.fecha_entrega_req = fecha_entrega_req; }

    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }

    public double getTotal_estimado() { return total_estimado; }
    public void setTotal_estimado(double total_estimado) { this.total_estimado = total_estimado; }

    public Integer getId_producto() { return id_producto; }
    public void setId_producto(Integer id_producto) { this.id_producto = id_producto; }
}