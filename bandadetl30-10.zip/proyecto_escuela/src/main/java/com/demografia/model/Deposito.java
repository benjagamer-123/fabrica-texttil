package com.demografia.model;

public class Deposito {
    private int id_deposito;
    private String nombre;
    private String ubicacion;
    private String descripcion;
    private String estado;

    public Deposito() {}
    public Deposito(int id_deposito, String nombre, String ubicacion, String descripcion, String estado) {
        this.id_deposito = id_deposito;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.descripcion = descripcion;
        this.estado = estado;
    }
    
    public Deposito( String nombre, String ubicacion, String descripcion, String estado) {
       
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.descripcion = descripcion;
        this.estado = estado;
    }

    public int getId_deposito() { return id_deposito; }
    public void setId_deposito(int id_deposito) { this.id_deposito = id_deposito; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
