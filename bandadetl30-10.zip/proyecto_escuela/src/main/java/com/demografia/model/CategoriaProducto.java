package com.demografia.model;

public class CategoriaProducto {
    private int id_categoria;
    private String nombre;
    private String descripcion;

    public CategoriaProducto() {}

    public CategoriaProducto(int id_categoria, String nombre, String descripcion) {
        this.id_categoria = id_categoria;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }
    
    public CategoriaProducto( String nombre, String descripcion) {
    
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public int getId_categoria() { return id_categoria; }
    public void setId_categoria(int id_categoria) { this.id_categoria = id_categoria; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}