package com.demografia.model;

import java.time.LocalDateTime;

public class Lote {

    private Integer idEtapa;
    private OrdenProduccion ordenProduccion; // Vinculación directa con el objeto de tu modelo
    private String nombreEtapa;
    private Integer ordenSecuencia;
    private String estado;
    private LocalDateTime fechaInicioReal; // Usar LocalDateTime es mejor para manejar fechas y horas juntas
    private LocalDateTime fechaFinReal;

    // Constructor vacío por defecto
    public Lote() {
    }

    // Constructor completo
    public Lote(Integer idEtapa, OrdenProduccion ordenProduccion, String nombreEtapa, 
                           Integer ordenSecuencia, String estado, LocalDateTime fechaInicioReal, LocalDateTime fechaFinReal) {
        this.idEtapa = idEtapa;
        this.ordenProduccion = ordenProduccion;
        this.nombreEtapa = nombreEtapa;
        this.ordenSecuencia = ordenSecuencia;
        this.estado = estado;
        this.fechaInicioReal = fechaInicioReal;
        this.fechaFinReal = fechaFinReal;
    }
    
    public Lote( OrdenProduccion ordenProduccion, String nombreEtapa, 
            Integer ordenSecuencia, String estado, LocalDateTime fechaInicioReal, LocalDateTime fechaFinReal) {

    		this.ordenProduccion = ordenProduccion;
    			this.nombreEtapa = nombreEtapa;
    				this.ordenSecuencia = ordenSecuencia;
    					this.estado = estado;
    						this.fechaInicioReal = fechaInicioReal;
    							this.fechaFinReal = fechaFinReal;
}

    // Getters y Setters en formato camelCase
    public Integer getIdEtapa() {
        return idEtapa;
    }

    public void setIdEtapa(Integer idEtapa) {
        this.idEtapa = idEtapa;
    }

    public OrdenProduccion getOrdenProduccion() {
        return ordenProduccion;
    }

    public void setOrdenProduccion(OrdenProduccion ordenProduccion) {
        this.ordenProduccion = ordenProduccion;
    }

    public String getNombreEtapa() {
        return nombreEtapa;
    }

    public void setNombreEtapa(String nombreEtapa) {
        this.nombreEtapa = nombreEtapa;
    }

    public Integer getOrdenSecuencia() {
        return ordenSecuencia;
    }

    public void setOrdenSecuencia(Integer ordenSecuencia) {
        this.ordenSecuencia = ordenSecuencia;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public LocalDateTime getFechaInicioReal() {
        return fechaInicioReal;
    }

    public void setFechaInicioReal(LocalDateTime fechaInicioReal) {
        this.fechaInicioReal = fechaInicioReal;
    }

    public LocalDateTime getFechaFinReal() {
        return fechaFinReal;
    }

    public void setFechaFinReal(LocalDateTime fechaFinReal) {
        this.fechaFinReal = fechaFinReal;
    }
}
