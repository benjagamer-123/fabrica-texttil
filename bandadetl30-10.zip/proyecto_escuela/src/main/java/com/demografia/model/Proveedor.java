package com.demografia.model;

public class Proveedor {
    private int id_proveedor;
    private String razon_social;
    private String cuit;
    private String contacto;
    private String email;
    private String telefono;
    private String direccion;
    private int id_pais;
    private String estado;

    public Proveedor() {}
    public Proveedor(int id_proveedor, String razon_social, String cuit, String contacto, String email, String telefono, String direccion, int id_pais, String estado) {
        this.id_proveedor = id_proveedor;
        this.razon_social = razon_social;
        this.cuit = cuit;
        this.contacto = contacto;
        this.email = email;
        this.telefono = telefono;
        this.direccion = direccion;
        this.id_pais = id_pais;
        this.estado = estado;
    }
    
    public Proveedor( String razon_social, String cuit, String contacto, String email, String telefono, String direccion, int id_pais, String estado) {
   
        this.razon_social = razon_social;
        this.cuit = cuit;
        this.contacto = contacto;
        this.email = email;
        this.telefono = telefono;
        this.direccion = direccion;
        this.id_pais = id_pais;
        this.estado = estado;
    }

    public int getId_proveedor() { return id_proveedor; }
    public void setId_proveedor(int id_proveedor) { this.id_proveedor = id_proveedor; }
    public String getRazon_social() { return razon_social; }
    public void setRazon_social(String razon_social) { this.razon_social = razon_social; }
    public String getCuit() { return cuit; }
    public void setCuit(String cuit) { this.cuit = cuit; }
    public String getContacto() { return contacto; }
    public void setContacto(String contacto) { this.contacto = contacto; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
    public int getId_pais() { return id_pais; }
    public void setId_pais(int id_pais) { this.id_pais = id_pais; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
