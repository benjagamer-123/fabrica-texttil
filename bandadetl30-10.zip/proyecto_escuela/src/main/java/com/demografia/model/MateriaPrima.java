package com.demografia.model;

public class MateriaPrima {
    private int id_materia_prima;
    private String codigo;
    private String nombre;
    private String tipo;
    private String unidad_medida;
    private double stock_minimo;
    private String estado;

    public MateriaPrima() {}
    public MateriaPrima(int id_materia_prima, String codigo, String nombre, String tipo, String unidad_medida, double stock_minimo, String estado) {
        this.id_materia_prima = id_materia_prima;
        this.codigo = codigo;
        this.nombre = nombre;
        this.tipo = tipo;
        this.unidad_medida = unidad_medida;
        this.stock_minimo = stock_minimo;
        this.estado = estado;
    }
    
    public MateriaPrima( String codigo, String nombre, String tipo, String unidad_medida, double stock_minimo, String estado) {
       
        this.codigo = codigo;
        this.nombre = nombre;
        this.tipo = tipo;
        this.unidad_medida = unidad_medida;
        this.stock_minimo = stock_minimo;
        this.estado = estado;
    }

    public int getId_materia_prima() { return id_materia_prima; }
    public void setId_materia_prima(int id_materia_prima) { this.id_materia_prima = id_materia_prima; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getUnidad_medida() { return unidad_medida; }
    public void setUnidad_medida(String unidad_medida) { this.unidad_medida = unidad_medida; }
    public double getStock_minimo() { return stock_minimo; }
    public void setStock_minimo(double stock_minimo) { this.stock_minimo = stock_minimo; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
