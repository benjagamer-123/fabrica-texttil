package com.demografia.model;

public class DetalleDespacho {
    private int id_detalle_despacho;
    private int id_despacho;
    private int id_producto;
    private double cantidad;

    public DetalleDespacho() {}
    public DetalleDespacho(int id_detalle_despacho, int id_despacho, int id_producto, double cantidad) {
        this.id_detalle_despacho = id_detalle_despacho;
        this.id_despacho = id_despacho;
        this.id_producto = id_producto;
        this.cantidad = cantidad;
    }
    
    public DetalleDespacho( double cantidad) {

        this.cantidad = cantidad;
    }
    
    

    public int getId_detalle_despacho() { return id_detalle_despacho; }
    public void setId_detalle_despacho(int id_detalle_despacho) { this.id_detalle_despacho = id_detalle_despacho; }
    public int getId_despacho() { return id_despacho; }
    public void setId_despacho(int id_despacho) { this.id_despacho = id_despacho; }
    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }
    public double getCantidad() { return cantidad; }
    public void setCantidad(double cantidad) { this.cantidad = cantidad; }
}
