package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IRedRelacion;
import com.demografia.model.RedRelacion;
import com.demografia.model.Rol;

public class RedRelacionDAOImpl implements IRedRelacion {

    @Override
    public void registrar(RedRelacion rr) {

        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";

        String cols = "id_rol_padre, id_rol_hijo";

        int idPadre = (rr.getRolPadre() != null)
                ? rr.getRolPadre().getId_rol()
                : 0;

        int idHijo = (rr.getRolHijo() != null)
                ? rr.getRolHijo().getId_rol()
                : 0;

        String vals = "'" + idPadre + "', '" + idHijo + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "red_relaciones");
            cst.setString(2, cols);
            cst.setString(3, vals);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(RedRelacion rr) {

        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";

        int idPadre = (rr.getRolPadre() != null)
                ? rr.getRolPadre().getId_rol()
                : 0;

        int idHijo = (rr.getRolHijo() != null)
                ? rr.getRolHijo().getId_rol()
                : 0;

        String sets = "id_rol_padre='" + idPadre
                + "', id_rol_hijo='" + idHijo + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "red_relaciones");
            cst.setString(2, sets);
            cst.setInt(3, rr.getIdRed());

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {

        String sql = "{CALL sp_eliminar_por_id(?, ?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "red_relaciones");
            cst.setInt(2, id);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public RedRelacion obtenerPorId(Integer id) {

        for (RedRelacion item : listarTodos()) {

            if (item.getIdRed() != null
                    && item.getIdRed().equals(id)) {

                return item;
            }
        }

        return null;
    }

    @Override
    public List<RedRelacion> listarTodos() {

        List<RedRelacion> lista = new ArrayList<>();

        String sql = "{CALL mostrar(?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "red_relaciones");

            try (ResultSet rs = cst.executeQuery()) {

                while (rs.next()) {

                    RedRelacion rr = new RedRelacion();

                    rr.setIdRed(
                            rs.getInt("id_red"));

                    Rol padre = new Rol();

                    padre.setId_rol(
                            rs.getInt("id_rol_padre"));

                    rr.setRolPadre(padre);

                    Rol hijo = new Rol();

                    hijo.setId_rol(
                            rs.getInt("id_rol_hijo"));

                    rr.setRolHijo(hijo);

                    lista.add(rr);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}