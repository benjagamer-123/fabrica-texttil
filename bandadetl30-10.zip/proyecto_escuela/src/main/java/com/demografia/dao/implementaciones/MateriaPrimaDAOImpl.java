package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IMateriaPrima;
import com.demografia.model.MateriaPrima;

public class MateriaPrimaDAOImpl implements IMateriaPrima {

    @Override
    public void registrar(MateriaPrima mp) {

        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";

        String cols = "codigo, nombre, tipo, unidad_medida, stock_minimo, estado";

        String vals = "'" + mp.getCodigo() + "', '"
                + mp.getNombre() + "', '"
                + mp.getTipo() + "', '"
                + mp.getUnidad_medida() + "', '"
                + mp.getStock_minimo() + "', '"
                + mp.getEstado() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "materias_primas");
            cst.setString(2, cols);
            cst.setString(3, vals);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(MateriaPrima mp) {

        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";

        String sets = "codigo='" + mp.getCodigo()
                + "', nombre='" + mp.getNombre()
                + "', tipo='" + mp.getTipo()
                + "', unidad_medida='" + mp.getUnidad_medida()
                + "', stock_minimo='" + mp.getStock_minimo()
                + "', estado='" + mp.getEstado() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "materias_primas");
            cst.setString(2, sets);
            cst.setInt(3, mp.getId_materia_prima());

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {

        String sql = "{CALL sp_eliminar_por_id(?, ?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "materias_primas");
            cst.setInt(2, id);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public MateriaPrima obtenerPorId(Integer id) {

        for (MateriaPrima item : listarTodos()) {

            if (item.getId_materia_prima() == id) {
                return item;
            }
        }

        return null;
    }

    @Override
    public List<MateriaPrima> listarTodos() {

        List<MateriaPrima> lista = new ArrayList<>();

        String sql = "{CALL mostrar(?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "materias_primas");

            try (ResultSet rs = cst.executeQuery()) {

                while (rs.next()) {

                    MateriaPrima mp = new MateriaPrima();

                    mp.setId_materia_prima(
                            rs.getInt("id_materia_prima"));

                    mp.setCodigo(
                            rs.getString("codigo"));

                    mp.setNombre(
                            rs.getString("nombre"));

                    mp.setTipo(
                            rs.getString("tipo"));

                    mp.setUnidad_medida(
                            rs.getString("unidad_medida"));

                    mp.setStock_minimo(
                            rs.getDouble("stock_minimo"));

                    mp.setEstado(
                            rs.getString("estado"));

                    lista.add(mp);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}