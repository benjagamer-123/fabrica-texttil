package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.ICliente;
import com.demografia.model.Cliente;

public class ClienteDAOImpl implements ICliente {

    @Override
    public void registrar(ICliente c) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "razon_social, cuit, tipo_cliente, email, telefono, direccion, ciudad, id_pais, estado";
        String vals = "'" + c.getRazon_social() + "', '" + c.getCuit() + "', '" + c.getTipo_cliente() + "', '" + c.getEmail() + "', '" + c.getTelefono() + "', '" + c.getDireccion() + "', '" + c.getCiudad() + "', '" + c.getId_pais() + "', '" + c.getEstado() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "clientes"); cst.setString(2, cols); cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void modificar(Cliente c) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "razon_social='" + c.getRazon_social() + "', cuit='" + c.getCuit() + "', tipo_cliente='" + c.getTipo_cliente() + "', email='" + c.getEmail() + "', telefono='" + c.getTelefono() + "', direccion='" + c.getDireccion() + "', ciudad='" + c.getCiudad() + "', id_pais='" + c.getId_pais() + "', estado='" + c.getEstado() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "clientes"); cst.setString(2, sets); cst.setInt(3, c.getId_cliente());
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "clientes"); cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public Cliente obtenerPorId(Integer id) {
        for (Cliente item : listarTodos()) {
            if (item.getId_cliente() == id) return item;
        }
        return null;
    }

    @Override
    public List<Cliente> listarTodos() {
        List<Cliente> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "clientes");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    Cliente c = new Cliente();
                    c.setId_cliente(rs.getInt("id_cliente"));
                    c.setRazon_social(rs.getString("razon_social"));
                    c.setCuit(rs.getString("cuit"));
                    c.setTipo_cliente(rs.getString("tipo_cliente"));
                    c.setEmail(rs.getString("email"));
                    c.setTelefono(rs.getString("telefono"));
                    c.setDireccion(rs.getString("direccion"));
                    c.setCiudad(rs.getString("ciudad")); // Corrección del ResultSet tradicional
                    c.setId_pais(rs.getInt("id_pais"));
                    c.setEstado(rs.getString("estado"));
                    lista.add(c);
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

	@Override
	public void registrar(Cliente cliente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getCuit() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getRazon_social() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTipo_cliente() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTelefono() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDireccion() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getId_pais() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCiudad() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getEstado() {
		// TODO Auto-generated method stub
		return null;
	}
}
