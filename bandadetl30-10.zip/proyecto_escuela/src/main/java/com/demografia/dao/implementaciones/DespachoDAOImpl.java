package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IDespacho;
import com.demografia.model.Despacho;

public class DespachoDAOImpl implements IDespacho {

    @Override
    public void registrar(Despacho d) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "fecha_despacho, id_pedido, transportista, estado";
        String vals = "NOW(), '" + d.getId_pedido() + "', '" + d.getTransportista() + "', '" + d.getEstado() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "despachos"); cst.setString(2, cols); cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void modificar(Despacho d) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "id_pedido='" + d.getId_pedido() + "', transportista='" + d.getTransportista() + "', estado='" + d.getEstado() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "despachos"); cst.setString(2, sets); cst.setInt(3, d.getId_despacho());
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void eliminar(Integer id) { 
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "despachos"); cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public Despacho obtenerPorId(Integer id) { 
        for (Despacho item : listarTodos()) {
            if (item.getId_despacho() == id) return item; 
        }
        return null;
    }


    @Override
    public List<Despacho> listarTodos() {
        List<Despacho> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "despachos");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    Despacho d = new Despacho();
                    d.setId_despacho(rs.getInt("id_despacho"));
                    d.setFecha_despacho(rs.getString("fecha_despacho"));
                    d.setId_pedido(rs.getInt("id_pedido"));
                    d.setTransportista(rs.getString("transportista"));
                    d.setEstado(rs.getString("estado"));
                    lista.add(d);
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }
}
