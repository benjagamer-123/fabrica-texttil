package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IConsumoMateriaPrima;
import com.demografia.model.ConsumoMateriaPrima;

public class ConsumoMateriaPrimaDAOImpl implements IConsumoMateriaPrima {

    @Override
    public void registrar(ConsumoMateriaPrima cmp) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "id_etapa, id_materia_prima, cantidad_utilizada, fecha_consumo, lote";
        String vals = "'" + cmp.getId_etapa() + "', '" + cmp.getId_materia_prima() + "', '" + cmp.getCantidad_utilizada() + "', NOW(), '" + cmp.getLote() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "consumos_materia_prima"); cst.setString(2, cols); cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void modificar(ConsumoMateriaPrima cmp) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "id_etapa='" + cmp.getId_etapa() + "', id_materia_prima='" + cmp.getId_materia_prima() + "', cantidad_utilizada='" + cmp.getCantidad_utilizada() + "', lote='" + cmp.getLote() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "consumos_materia_prima"); cst.setString(2, sets); cst.setInt(3, cmp.getId_consumo());
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "consumos_materia_prima"); cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public ConsumoMateriaPrima obtenerPorId(Integer id) {
        for (ConsumoMateriaPrima item : listarTodos()) {
            if (item.getId_consumo() == id) return item;
        }
        return null;
    }

    @Override
    public List<ConsumoMateriaPrima> listarTodos() {
        List<ConsumoMateriaPrima> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "consumos_materia_prima");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    ConsumoMateriaPrima cmp = new ConsumoMateriaPrima();
                    cmp.setId_consumo(rs.getInt("id_consumo"));
                    cmp.setId_etapa(rs.getInt("id_etapa"));
                    cmp.setId_materia_prima(rs.getInt("id_materia_prima"));
                    cmp.setCantidad_utilizada(rs.getDouble("cantidad_utilizada"));
                    cmp.setFecha_consumo(rs.getString("fecha_consumo"));    
                    cmp.setLote(rs.getString("lote"));
                    lista.add(cmp);
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }
}
