package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IInventario;
import com.demografia.model.Inventario;

public class InventarioDAOImpl implements IInventario {

    @Override
    public void registrar(Inventario i) {

        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";

        String cols = "id_producto, id_deposito, lote, cantidad_disponible, unidad_medida, fecha_actualizacion";

        String vals = "'" + i.getId_producto() + "', '"
                + i.getId_deposito() + "', '"
                + i.getLote() + "', '"
                + i.getCantidad_disponible() + "', '"
                + i.getUnidad_medida() + "', NOW()";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "inventarios");
            cst.setString(2, cols);
            cst.setString(3, vals);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Inventario i) {

        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";

        String sets = "id_producto='" + i.getId_producto()
                + "', id_deposito='" + i.getId_deposito()
                + "', lote='" + i.getLote()
                + "', cantidad_disponible='" + i.getCantidad_disponible()
                + "', unidad_medida='" + i.getUnidad_medida() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "inventarios");
            cst.setString(2, sets);
            cst.setInt(3, i.getId_inventario());

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {

        String sql = "{CALL sp_eliminar_por_id(?, ?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "inventarios");
            cst.setInt(2, id);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Inventario obtenerPorId(Integer id) {

        for (Inventario item : listarTodos()) {

            if (item.getId_inventario() == id) {
                return item;
            }
        }

        return null;
    }

    @Override
    public List<Inventario> listarTodos() {

        List<Inventario> lista = new ArrayList<>();

        String sql = "{CALL mostrar(?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "inventarios");

            try (ResultSet rs = cst.executeQuery()) {

                while (rs.next()) {

                    Inventario i = new Inventario();

                    i.setId_inventario(
                            rs.getInt("id_inventario"));

                    i.setId_producto(
                            rs.getInt("id_producto"));

                    i.setId_deposito(
                            rs.getInt("id_deposito"));

                    i.setLote(
                            rs.getString("lote"));

                    i.setCantidad_disponible(
                            rs.getDouble("cantidad_disponible"));

                    i.setUnidad_medida(
                            rs.getString("unidad_medida"));

                    i.setFecha_actualizacion(
                            rs.getString("fecha_actualizacion"));

                    lista.add(i);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}