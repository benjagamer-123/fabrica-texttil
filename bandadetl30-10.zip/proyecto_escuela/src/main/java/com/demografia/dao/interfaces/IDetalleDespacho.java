package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.DetalleDespacho;

public interface IDetalleDespacho {
    void registrar(DetalleDespacho detalleDespacho);
    void modificar(DetalleDespacho detalleDespacho);
    void eliminar(Integer id);
    DetalleDespacho obtenerPorId(Integer id);
    List<DetalleDespacho> listarTodos();
}
