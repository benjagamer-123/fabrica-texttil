package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IAuditoria;
import com.demografia.model.Auditoria;

public class AuditoriaDAOImpl implements IAuditoria {

    @Override
    public void registrar(Auditoria a) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "id_usuario, tabla_affected, id_registro, accion, fecha_hora, detalle_anterior, detalle_nuevo, ip_origen";
        String vals = "'" + a.getId_usuario() + "', '" + a.getTabla_affected() + "', '" + a.getId_registro() + "', '" + a.getAccion() + "', NOW(), '" + a.getDetalle_anterior() + "', '" + a.getDetalle_nuevo() + "', '" + a.getIp_origen() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "auditorias"); cst.setString(2, cols); cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void modificar(Auditoria a) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "id_usuario='" + a.getId_usuario() + "', tabla_affected='" + a.getTabla_affected() + "', id_registro='" + a.getId_registro() + "', accion='" + a.getAccion() + "', detalle_anterior='" + a.getDetalle_anterior() + "', detalle_nuevo='" + a.getDetalle_nuevo() + "', ip_origen='" + a.getIp_origen() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "auditorias"); cst.setString(2, sets); cst.setInt(3, a.getId_auditoria());
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "auditorias"); cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public Auditoria obtenerPorId(Integer id) {
        for (Auditoria item : listarTodos()) {
            if (item.getId_auditoria() == id) return item;
        }
        return null;
    }

    @Override
    public List<Auditoria> listarTodos() {
        List<Auditoria> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "auditorias");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    Auditoria a = new Auditoria();
                    a.setId_auditoria(rs.getInt("id_auditoria")); a.setId_usuario(rs.getInt("id_usuario"));
                    a.setTabla_affected(rs.getString("tabla_affected")); a.setId_registro(rs.getInt("id_registro"));
                    a.setAccion(rs.getString("accion")); a.setFecha_hora(rs.getTimestamp("fecha_hora"));
                    a.setDetalle_anterior(rs.getString("detalle_anterior")); a.setDetalle_nuevo(rs.getString("detalle_nuevo"));
                    a.setIp_origen(rs.getString("ip_origen"));
                    lista.add(a);
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }
}
