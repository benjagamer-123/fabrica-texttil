package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IUsuario;
import com.demografia.model.Usuario;

public class UsuarioDAOImpl implements IUsuario {

    @Override
    public boolean registrar(Usuario u) {
        // Llamamos al Stored Procedure usando parámetros seguros (?)
        String sql = "{CALL sp_registrar_usuario(?, ?, ?, ?, ?)}";
                
        try (Connection con = Conexion.getConnection(); 
             CallableStatement cst = con.prepareCall(sql)) {
            
            cst.setString(1, u.getNombre());
            cst.setString(2, u.getEmail());
            cst.setString(3, u.getPassword_hash());
            cst.setString(4, u.getEstado());
            cst.setInt(5, u.getId_rol()); // Lo envía como número puro, sin comillas rotas
            
            cst.executeUpdate();
            return true; // Retorna true si se guardó con éxito
            
        } catch (SQLException e) {
            System.err.println("Error en sp_registrar_usuario: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void modificar(Usuario u) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "nombre='" + u.getNombre() + "', email='" + u.getEmail() 
                    + "', password_hash='" + u.getPassword_hash() + "', estado='" + u.getEstado() 
                    + "', id_rol=" + u.getId_rol();
                    
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "usuarios");
            cst.setString(2, sets);
            cst.setInt(3, u.getId_usuario());
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "usuarios");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Usuario obtenerPorId(Integer id) {
        for (Usuario item : listarTodos()) {
            if (item.getId_usuario() == id) return item;
        }
        return null;
    }

    @Override
    public List<Usuario> listarTodos() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "usuarios");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    Usuario u = new Usuario();
                    u.setId_usuario(rs.getInt("id_usuario"));
                    u.setNombre(rs.getString("nombre"));
                    u.setEmail(rs.getString("email"));
                    u.setPassword_hash(rs.getString("password_hash"));
                    u.setEstado(rs.getString("estado"));
                    u.setId_rol(rs.getInt("id_rol"));
                    lista.add(u);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
