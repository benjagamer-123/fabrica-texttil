package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IRol;
import com.demografia.model.Rol;

public class RolDAOImpl implements IRol {

    @Override
    public void registrar(Rol r) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "nombre, descripcion";
        String vals = "'" + r.getNombre() + "', '" + r.getDescripcion() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "roles");
            cst.setString(2, cols);
            cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Rol r) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "nombre='" + r.getNombre() + "', descripcion='" + r.getDescripcion() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "roles");
            cst.setString(2, sets);
            cst.setInt(3, r.getId_rol());
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "roles");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Rol obtenerPorId(Integer id) {
        for (Rol item : listarTodos()) {
            if (item.getId_rol() == id) return item;
        }
        return null;
    }

    @Override
    public List<Rol> listarTodos() {
        List<Rol> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "roles");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    Rol r = new Rol();
                    r.setId_rol(rs.getInt("id_rol"));
                    r.setNombre(rs.getString("nombre"));
                    r.setDescripcion(rs.getString("descripcion"));
                    lista.add(r);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}