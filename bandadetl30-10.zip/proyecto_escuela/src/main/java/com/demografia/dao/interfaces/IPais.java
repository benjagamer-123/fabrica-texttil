package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.Pais;

public interface IPais {
    void registrar(Pais pais);
    void modificar(Pais pais);
    void eliminar(Integer id);
    Pais obtenerPorId(Integer id);
    List<Pais> listarTodos();
}
