package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IProveedor;
import com.demografia.model.Proveedor;

public class ProveedorDAOImpl implements IProveedor {

    @Override
    public void registrar(Proveedor p) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "razon_social, cuit, contacto, email, telefono, direccion, id_pais, estado";
        String vals = "'" + p.getRazon_social() + "', '" + p.getCuit() + "', '" + p.getContacto() + "', '" 
                    + p.getEmail() + "', '" + p.getTelefono() + "', '" + p.getDireccion() + "', '" 
                    + p.getId_pais() + "', '" + p.getEstado() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "proveedores");
            cst.setString(2, cols);
            cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Proveedor p) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "razon_social='" + p.getRazon_social() + "', cuit='" + p.getCuit() + "', contacto='" + p.getContacto() 
                    + "', email='" + p.getEmail() + "', telefono='" + p.getTelefono() + "', direccion='" + p.getDireccion() 
                    + "', id_pais='" + p.getId_pais() + "', estado='" + p.getEstado() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "proveedores");
            cst.setString(2, sets);
            cst.setInt(3, p.getId_proveedor());
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "proveedores");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Proveedor obtenerPorId(Integer id) {
        for (Proveedor item : listarTodos()) {
            if (item.getId_proveedor() == id) return item;
        }
        return null;
    }

    @Override
    public List<Proveedor> listarTodos() {
        List<Proveedor> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "proveedores");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    Proveedor p = new Proveedor();
                    p.setId_proveedor(rs.getInt("id_proveedor"));
                    p.setRazon_social(rs.getString("razon_social"));
                    p.setCuit(rs.getString("cuit"));
                    p.setContacto(rs.getString("contacto"));
                    p.setEmail(rs.getString("email"));
                    p.setTelefono(rs.getString("telefono"));
                    p.setDireccion(rs.getString("direccion"));
                    p.setId_pais(rs.getInt("id_pais"));
                    p.setEstado(rs.getString("estado"));
                    lista.add(p);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}