package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.OrdenProduccion;

public interface IOrdenProduccion {
    void registrar(OrdenProduccion ordenProduccion);
    void modificar(OrdenProduccion ordenProduccion);
    void eliminar(Integer id);
    OrdenProduccion obtenerPorId(Integer id);
    List<OrdenProduccion> listarTodos();
}