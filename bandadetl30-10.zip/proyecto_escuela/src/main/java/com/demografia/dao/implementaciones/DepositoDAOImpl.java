package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IDeposito;
import com.demografia.model.Deposito;

public class DepositoDAOImpl implements IDeposito {

    @Override
    public void registrar(Deposito d) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "nombre, ubicacion, descripcion, estado";
        String vals = "'" + d.getNombre() + "', '" + d.getUbicacion() + "', '" + d.getDescripcion() + "', '" + d.getEstado() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "depositos"); cst.setString(2, cols); cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void modificar(Deposito d) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "nombre='" + d.getNombre() + "', ubicacion='" + d.getUbicacion() + "', descripcion='" + d.getDescripcion() + "', estado='" + d.getEstado() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "depositos"); cst.setString(2, sets); cst.setInt(3, d.getId_deposito());
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void eliminar(int id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "depositos"); cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public Deposito obtenerPorId(int id) {
        for (Deposito item : listarTodos()) {
            if (item.getId_deposito() == id) return item;
        }
        return null;
    }

    @Override
    public List<Deposito> listarTodos() {
        List<Deposito> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "depositos");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    Deposito d = new Deposito();
                    d.setId_deposito(rs.getInt("id_deposito"));
                    d.setNombre(rs.getString("nombre"));
                    d.setUbicacion(rs.getString("ubicacion"));
                    d.setDescripcion(rs.getString("descripcion"));
                    d.setEstado(rs.getString("estado"));
                    lista.add(d);
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }
}



