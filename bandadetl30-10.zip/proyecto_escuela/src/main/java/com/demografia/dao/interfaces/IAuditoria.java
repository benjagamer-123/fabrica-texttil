
package com.demografia.dao.interfaces;
import com.demografia.model.Auditoria;


import java.util.List;


public interface IAuditoria {
    void registrar(Auditoria auditoria);
    void modificar(Auditoria auditoria);
    void eliminar(Integer id);
    Auditoria obtenerPorId(Integer id);
    List<Auditoria> listarTodos();
}
