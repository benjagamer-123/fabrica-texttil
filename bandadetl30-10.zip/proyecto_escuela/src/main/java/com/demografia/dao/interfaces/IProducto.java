package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.Producto;

public interface IProducto {
    void registrar(Producto producto);
    void modificar(Producto producto);
    void eliminar(Integer id);
    Producto obtenerPorId(Integer id);
    List<Producto> listarTodos();
}
