package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.ICategoriaProducto;
import com.demografia.model.CategoriaProducto;

public class CategoriaProductoDAOImpl implements ICategoriaProducto {

    @Override
    public void registrar(CategoriaProducto cp) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "nombre, descripcion";
        String vals = "'" + cp.getNombre() + "', '" + cp.getDescripcion() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "categorias_productos"); cst.setString(2, cols); cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void modificar(CategoriaProducto cp) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "nombre='" + cp.getNombre() + "', descripcion='" + cp.getDescripcion() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "categorias_productos"); cst.setString(2, sets); cst.setInt(3, cp.getId_categoria());
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "categorias_productos"); cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public CategoriaProducto obtenerPorId(Integer id) {
        for (CategoriaProducto item : listarTodos()) {
            if (item.getId_categoria() == id) return item;
        }
        return null;
    }

    @Override
    public List<CategoriaProducto> listarTodos() {
        List<CategoriaProducto> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "categorias_productos");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    CategoriaProducto cp = new CategoriaProducto();
                    cp.setId_categoria(rs.getInt("id_categoria"));
                    cp.setNombre(rs.getString("nombre"));
                    cp.setDescripcion(rs.getString("descripcion"));
                    lista.add(cp);
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }
}
