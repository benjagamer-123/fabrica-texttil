package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IDetalleOrdenProd;
import com.demografia.model.DetalleOrdenProd;

public class DetalleOrdenProdDAOImpl implements IDetalleOrdenProd {

    @Override
    public void registrar(DetalleOrdenProd dop) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "id_orden_prod, id_producto, cantidad_plan, tiempo_unitario_est, tiempo_total_est";
        String vals = "'" + dop.getId_orden_prod() + "', '" + dop.getId_producto() + "', '" + dop.getCantidad_plan() + "', '" + dop.getTiempo_unitario_est() + "', '" + dop.getTiempo_total_est() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "detalles_orden_prod");
            cst.setString(2, cols);
            cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(DetalleOrdenProd dop) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "id_orden_prod='" + dop.getId_orden_prod() + "', id_producto='" + dop.getId_producto() + "', cantidad_plan='" + dop.getCantidad_plan() + "', tiempo_unitario_est='" + dop.getTiempo_unitario_est() + "', tiempo_total_est='" + dop.getTiempo_total_est() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "detalles_orden_prod");
            cst.setString(2, sets);
            cst.setInt(3, dop.getId_detalle_orden_prod());
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "detalles_orden_prod");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public DetalleOrdenProd obtenerPorId(Integer id) {
        for (DetalleOrdenProd item : listarTodos()) {
            if (item.getId_detalle_orden_prod() == id) return item;
        }
        return null;
    }

    @Override
    public List<DetalleOrdenProd> listarTodos() {
        List<DetalleOrdenProd> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "detalles_orden_prod");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    DetalleOrdenProd dop = new DetalleOrdenProd();
                    dop.setId_detalle_orden_prod(rs.getInt("id_detalle_orden_prod"));
                    dop.setId_orden_prod(rs.getInt("id_orden_prod"));
                    dop.setId_producto(rs.getInt("id_producto"));
                    dop.setCantidad_plan(rs.getDouble("cantidad_plan"));
                    dop.setTiempo_unitario_est(rs.getDouble("tiempo_unitario_est"));
                    dop.setTiempo_total_est(rs.getDouble("tiempo_total_est"));
                    lista.add(dop);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}