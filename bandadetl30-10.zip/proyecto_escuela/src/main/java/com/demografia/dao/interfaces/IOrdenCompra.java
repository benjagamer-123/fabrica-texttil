package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.OrdenCompra;

public interface IOrdenCompra {
    void registrar(OrdenCompra ordenCompra);
    void modificar(OrdenCompra ordenCompra);
    void eliminar(Integer id);
    OrdenCompra obtenerPorId(Integer id);
    List<OrdenCompra> listarTodos();
}
