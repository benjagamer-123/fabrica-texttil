package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.MateriaPrima;

public interface IMateriaPrima {
    void registrar(MateriaPrima materiaPrima);
    void modificar(MateriaPrima materiaPrima);
    void eliminar(Integer id);
    MateriaPrima obtenerPorId(Integer id);
    List<MateriaPrima> listarTodos();
}
