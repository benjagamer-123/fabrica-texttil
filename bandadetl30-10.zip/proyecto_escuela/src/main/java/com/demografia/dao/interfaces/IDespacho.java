package com.demografia.dao.interfaces;

import java.util.List;

import com.demografia.model.Despacho;

public interface IDespacho {
    void registrar(Despacho despacho);
    void modificar(Despacho despacho);
    void eliminar(Integer id);
    Despacho obtenerPorId(Integer id);
    List<Despacho> listarTodos();
}
