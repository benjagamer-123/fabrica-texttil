package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IPais;
import com.demografia.model.Pais;

public class PaisDAOImpl implements IPais {

    @Override
    public void registrar(Pais p) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "nombre, codigo_iso";
        String vals = "'" + p.getNombre() + "', '" + p.getCodigo_iso() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "paises");
            cst.setString(2, cols);
            cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Pais p) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "nombre='" + p.getNombre() + "', codigo_iso='" + p.getCodigo_iso() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "paises");
            cst.setString(2, sets);
            cst.setInt(3, p.getId_pais());
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "paises");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Pais obtenerPorId(Integer id) {
        for (Pais item : listarTodos()) {
            if (item.getId_pais() == id) return item;
        }
        return null;
    }

    @Override
    public List<Pais> listarTodos() {
        List<Pais> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "paises");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    Pais p = new Pais();
                    p.setId_pais(rs.getInt("id_pais"));
                    p.setNombre(rs.getString("nombre"));
                    p.setCodigo_iso(rs.getString("codigo_iso"));
                    lista.add(p);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}