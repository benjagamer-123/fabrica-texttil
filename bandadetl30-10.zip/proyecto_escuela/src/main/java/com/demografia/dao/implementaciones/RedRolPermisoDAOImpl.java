package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IRedRolPermiso;
import com.demografia.model.Permiso;
import com.demografia.model.RedRolPermiso;
import com.demografia.model.Rol;

public class RedRolPermisoDAOImpl implements IRedRolPermiso {

    @Override
    public void registrar(RedRolPermiso rrp) {

        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";

        String cols = "id_rol, id_permiso";

        int idRol = (rrp.getRol() != null)
                ? rrp.getRol().getId_rol()
                : 0;

        int idPermiso = (rrp.getPermiso() != null)
                ? rrp.getPermiso().getIdPermisos()
                : 0;

        String vals = "'" + idRol + "', '" + idPermiso + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "red_rol_permiso");
            cst.setString(2, cols);
            cst.setString(3, vals);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(RedRolPermiso rrp) {

        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";

        int idRol = (rrp.getRol() != null)
                ? rrp.getRol().getId_rol()
                : 0;

        int idPermiso = (rrp.getPermiso() != null)
                ? rrp.getPermiso().getIdPermisos()
                : 0;

        String sets = "id_rol='" + idRol
                + "', id_permiso='" + idPermiso + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "red_rol_permiso");
            cst.setString(2, sets);
            cst.setInt(3, rrp.getIdRedRolPermiso());

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {

        String sql = "{CALL sp_eliminar_por_id(?, ?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "red_rol_permiso");
            cst.setInt(2, id);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public RedRolPermiso obtenerPorId(Integer id) {

        for (RedRolPermiso item : listarTodos()) {

            if (item.getIdRedRolPermiso() != null
                    && item.getIdRedRolPermiso().equals(id)) {

                return item;
            }
        }

        return null;
    }

    @Override
    public List<RedRolPermiso> listarTodos() {

        List<RedRolPermiso> lista = new ArrayList<>();

        String sql = "{CALL mostrar(?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "red_rol_permiso");

            try (ResultSet rs = cst.executeQuery()) {

                while (rs.next()) {

                    RedRolPermiso rrp = new RedRolPermiso();

                    rrp.setIdRedRolPermiso(
                            rs.getInt("id"));

                    Rol rol = new Rol();

                    rol.setId_rol(
                            rs.getInt("id_rol"));

                    rrp.setRol(rol);

                    Permiso permiso = new Permiso();

                    permiso.setIdPermisos(
                            rs.getInt("id_permiso"));

                    rrp.setPermiso(permiso);

                    lista.add(rrp);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}