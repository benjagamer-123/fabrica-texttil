package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IProducto;
import com.demografia.model.Producto;

public class ProductoDAOImpl implements IProducto {

    @Override
    public void registrar(Producto p) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "codigo, nombre, descripcion, unidad_medida, tipo, id_categoria";
        String vals = "'" + p.getCodigo() + "', '" + p.getNombre() + "', '" + p.getDescripcion() + "', '" 
                    + p.getUnidad_medida() + "', '" + p.getTipo() + "', '" + p.getId_categoria() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "productos");
            cst.setString(2, cols);
            cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Producto p) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "codigo='" + p.getCodigo() + "', nombre='" + p.getNombre() 
                    + "', descripcion='" + p.getDescripcion() + "', unidad_medida='" + p.getUnidad_medida() 
                    + "', tipo='" + p.getTipo() + "', id_categoria='" + p.getId_categoria() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "productos");
            cst.setString(2, sets);
            cst.setInt(3, p.getId_producto());
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "productos");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Producto obtenerPorId(Integer id) {
        for (Producto item : listarTodos()) {
            if (item.getId_producto() == id) return item;
        }
        return null;
    }

    @Override
    public List<Producto> listarTodos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "productos");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    Producto p = new Producto();
                    p.setId_producto(rs.getInt("id_producto"));
                    p.setCodigo(rs.getString("codigo"));
                    p.setNombre(rs.getString("nombre"));
                    p.setDescripcion(rs.getString("descripcion"));
                    p.setUnidad_medida(rs.getString("unidad_medida"));
                    p.setTipo(rs.getString("tipo"));
                    p.setId_categoria(rs.getInt("id_categoria"));
                    lista.add(p);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}