package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.Proveedor;

public interface IProveedor {
    void registrar(Proveedor proveedor);
    void modificar(Proveedor proveedor);
    void eliminar(Integer id);
    Proveedor obtenerPorId(Integer id);
    List<Proveedor> listarTodos();
}
