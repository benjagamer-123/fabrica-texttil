package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IPermiso;
import com.demografia.model.Permiso;

public class PermisoDAOImpl implements IPermiso {

    @Override
    public void registrar(Permiso p) {

        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";

        String cols = "nombre, descripcion";

        String vals = "'" + p.getNombre() + "', '"
                + p.getDescripcion() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "permisos");
            cst.setString(2, cols);
            cst.setString(3, vals);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Permiso p) {

        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";

        String sets = "nombre='" + p.getNombre()
                + "', descripcion='" + p.getDescripcion() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "permisos");
            cst.setString(2, sets);
            cst.setInt(3, p.getIdPermisos());

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {

        String sql = "{CALL sp_eliminar_por_id(?, ?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "permisos");
            cst.setInt(2, id);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Permiso obtenerPorId(Integer id) {

        for (Permiso item : listarTodos()) {

            if (item.getIdPermisos() != null
                    && item.getIdPermisos().equals(id)) {

                return item;
            }
        }

        return null;
    }

    @Override
    public List<Permiso> listarTodos() {

        List<Permiso> lista = new ArrayList<>();

        String sql = "{CALL mostrar(?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "permisos");

            try (ResultSet rs = cst.executeQuery()) {

                while (rs.next()) {

                    Permiso p = new Permiso();

                    p.setIdPermisos(
                            rs.getInt("id_permiso"));

                    p.setNombre(
                            rs.getString("nombre"));

                    p.setDescripcion(
                            rs.getString("descripcion"));

                    lista.add(p);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}