package com.demografia.dao.interfaces;

import java.util.List;
import com.demografia.model.Usuario;

public interface IUsuario {
    public boolean registrar(Usuario u); // Cambiado a boolean
    public void modificar(Usuario u);
    public void eliminar(Integer id);
    public Usuario obtenerPorId(Integer id);
    public List<Usuario> listarTodos();
}
