package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.Pedido;

public interface IPedido {
    void registrar(Pedido pedido);
    void modificar(Pedido pedido);
    void eliminar(Integer id);
    Pedido obtenerPorId(Integer id);
    List<Pedido> listarTodos();
}