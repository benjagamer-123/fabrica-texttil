package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IDetalleOrdenCompra;
import com.demografia.model.DetalleOrdenCompra;

public class DetalleOrdenCompraDAOImpl implements IDetalleOrdenCompra {

    @Override
    public void insert(DetalleOrdenCompra doc) throws SQLException {

        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";

        String cols = "id_orden_compra, id_materia_prima, cantidad, precio_unitario";

        String vals = "'" + doc.getId_orden_compra() + "', '"
                + doc.getId_materia_prima() + "', '"
                + doc.getCantidad() + "', '"
                + doc.getPrecio_unitario() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "detalles_orden_compra");
            cst.setString(2, cols);
            cst.setString(3, vals);

            cst.executeUpdate();
        }
    }

    @Override
    public void update(DetalleOrdenCompra doc) {

        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";

        String sets = "id_orden_compra='" + doc.getId_orden_compra()
                + "', id_materia_prima='" + doc.getId_materia_prima()
                + "', cantidad='" + doc.getCantidad()
                + "', precio_unitario='" + doc.getPrecio_unitario() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "detalles_orden_compra");
            cst.setString(2, sets);
            cst.setInt(3, doc.getId_detalle_compra());

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Integer id) {

        String sql = "{CALL sp_eliminar_por_id(?, ?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "detalles_orden_compra");
            cst.setInt(2, id);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public DetalleOrdenCompra listById(Integer id) {

        for (DetalleOrdenCompra item : listAll()) {

            if (item.getId_detalle_compra() == id) {
                return item;
            }
        }

        return null;
    }

    @Override
    public List<DetalleOrdenCompra> listAll() {

        List<DetalleOrdenCompra> lista = new ArrayList<>();

        String sql = "{CALL mostrar(?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "detalles_orden_compra");

            try (ResultSet rs = cst.executeQuery()) {

                while (rs.next()) {

                    DetalleOrdenCompra doc = new DetalleOrdenCompra();

                    doc.setId_detalle_compra(
                            rs.getInt("id_detalle_compra"));

                    doc.setId_orden_compra(
                            rs.getInt("id_orden_compra"));

                    doc.setId_materia_prima(
                            rs.getInt("id_materia_prima"));

                    doc.setCantidad(
                            rs.getDouble("cantidad"));

                    doc.setPrecio_unitario(
                            rs.getDouble("precio_unitario"));

                    lista.add(doc);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}