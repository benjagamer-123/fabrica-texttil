package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.Rol;

public interface IRol {
    void registrar(Rol rol);
    void modificar(Rol rol);
    void eliminar(Integer id);
    Rol obtenerPorId(Integer id);
    List<Rol> listarTodos();
}
