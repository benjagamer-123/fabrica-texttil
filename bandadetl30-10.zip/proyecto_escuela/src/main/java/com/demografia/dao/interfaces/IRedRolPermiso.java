package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.RedRolPermiso;

public interface IRedRolPermiso {
    void registrar(RedRolPermiso redRolPermiso);
    void modificar(RedRolPermiso redRolPermiso);
    void eliminar(Integer id);
    RedRolPermiso obtenerPorId(Integer id);
    List<RedRolPermiso> listarTodos();
}
