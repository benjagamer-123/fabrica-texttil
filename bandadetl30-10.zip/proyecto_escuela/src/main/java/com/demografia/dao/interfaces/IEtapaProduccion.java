package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.EtapaProduccion;

public interface IEtapaProduccion {
    void registrar(EtapaProduccion etapaProduccion);
    void modificar(EtapaProduccion etapaProduccion);
    void eliminar(Integer id);
    EtapaProduccion obtenerPorId(Integer id);
    List<EtapaProduccion> listarTodos();
}
