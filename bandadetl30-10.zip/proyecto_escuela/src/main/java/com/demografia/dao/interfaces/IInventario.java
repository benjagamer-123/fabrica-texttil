package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.Inventario;

public interface IInventario {
    void registrar(Inventario inventario);
    void modificar(Inventario inventario);
    void eliminar(Integer id);
    Inventario obtenerPorId(Integer id);
    List<Inventario> listarTodos();
}
