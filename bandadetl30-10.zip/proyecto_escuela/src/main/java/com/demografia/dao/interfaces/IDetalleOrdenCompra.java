package com.demografia.dao.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.demografia.model.DetalleOrdenCompra;

public interface IDetalleOrdenCompra {

    void insert(DetalleOrdenCompra doc) throws SQLException;

    void update(DetalleOrdenCompra doc);

    void delete(Integer id);

    DetalleOrdenCompra listById(Integer id);

    List<DetalleOrdenCompra> listAll();
}