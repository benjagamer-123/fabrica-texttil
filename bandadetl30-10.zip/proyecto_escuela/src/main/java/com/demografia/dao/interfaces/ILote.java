package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.Lote;

public interface ILote {
    void registrar(Lote lote);
    void modificar(Lote lote);
    void eliminar(Integer id);
    Lote obtenerPorId(Integer id);
    List<Lote> listarTodos();
}
