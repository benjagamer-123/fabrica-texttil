package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IDetalleDespacho;
import com.demografia.model.DetalleDespacho;

public class DetalleDespachoDAOImpl implements IDetalleDespacho {

    @Override
    public void registrar(DetalleDespacho dd) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "id_despacho, id_producto, cantidad";
        String vals = "'" + dd.getId_despacho() + "', '" + dd.getId_producto() + "', '" + dd.getCantidad() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "detalles_despacho");
            cst.setString(2, cols);
            cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(DetalleDespacho dd) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "id_despacho='" + dd.getId_despacho() + "', id_producto='" + dd.getId_producto() + "', cantidad='" + dd.getCantidad() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "detalles_despacho");
            cst.setString(2, sets);
            cst.setInt(3, dd.getId_detalle_despacho());
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "detalles_despacho");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public DetalleDespacho obtenerPorId(Integer id) {
        for (DetalleDespacho item : listarTodos()) {
            if (item.getId_detalle_despacho() == id) return item;
        }
        return null;
    }

    @Override
    public List<DetalleDespacho> listarTodos() {
        List<DetalleDespacho> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "detalles_despacho");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    DetalleDespacho dd = new DetalleDespacho();
                    dd.setId_detalle_despacho(rs.getInt("id_detalle_despacho"));
                    dd.setId_despacho(rs.getInt("id_despacho"));
                    dd.setId_producto(rs.getInt("id_producto"));
                    dd.setCantidad(rs.getDouble("cantidad"));
                    lista.add(dd);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}