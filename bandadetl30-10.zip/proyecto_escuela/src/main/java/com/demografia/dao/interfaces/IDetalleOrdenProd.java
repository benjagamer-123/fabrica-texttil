package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.DetalleOrdenProd;

public interface IDetalleOrdenProd {
    void registrar(DetalleOrdenProd detalleOrdenProd);
    void modificar(DetalleOrdenProd detalleOrdenProd);
    void eliminar(Integer id);
    DetalleOrdenProd obtenerPorId(Integer id);
    List<DetalleOrdenProd> listarTodos();
}
