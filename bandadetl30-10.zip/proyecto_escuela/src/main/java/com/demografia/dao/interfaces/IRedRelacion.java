package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.RedRelacion;

public interface IRedRelacion {
    void registrar(RedRelacion redRelacion);
    void modificar(RedRelacion redRelacion);
    void eliminar(Integer id);
    RedRelacion obtenerPorId(Integer id);
    List<RedRelacion> listarTodos();
}
