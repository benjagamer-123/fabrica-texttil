package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IDetallePedido;
import com.demografia.model.DetallePedido;

public class DetallePedidoDAOImpl implements IDetallePedido {

    @Override
    public void registrar(DetallePedido dp) {

        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";

        String cols = "id_pedido, id_producto, cantidad, precio_unitario, descuento, subtotal";

        String vals = "'" + dp.getId_pedido() + "', '"
                + dp.getId_producto() + "', '"
                + dp.getCantidad() + "', '"
                + dp.getPrecio_unitario() + "', '"
                + dp.getDescuento() + "', '"
                + dp.getSubtotal() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "detalles_pedido");
            cst.setString(2, cols);
            cst.setString(3, vals);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(DetallePedido dp) {

        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";

        String sets = "id_pedido='" + dp.getId_pedido()
                + "', id_producto='" + dp.getId_producto()
                + "', cantidad='" + dp.getCantidad()
                + "', precio_unitario='" + dp.getPrecio_unitario()
                + "', descuento='" + dp.getDescuento()
                + "', subtotal='" + dp.getSubtotal() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "detalles_pedido");
            cst.setString(2, sets);
            cst.setInt(3, dp.getId_detalle_pedido());

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {

        String sql = "{CALL sp_eliminar_por_id(?, ?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "detalles_pedido");
            cst.setInt(2, id);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public DetallePedido obtenerPorId(Integer id) {

        for (DetallePedido item : listarTodos()) {

            if (item.getId_detalle_pedido() == id) {
                return item;
            }
        }

        return null;
    }

    @Override
    public List<DetallePedido> listarTodos() {

        List<DetallePedido> lista = new ArrayList<>();

        String sql = "{CALL mostrar(?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "detalles_pedido");

            try (ResultSet rs = cst.executeQuery()) {

                while (rs.next()) {

                    DetallePedido dp = new DetallePedido();

                    dp.setId_detalle_pedido(
                            rs.getInt("id_detalle_pedido"));

                    dp.setId_pedido(
                            rs.getInt("id_pedido"));

                    dp.setId_producto(
                            rs.getInt("id_producto"));

                    dp.setCantidad(
                            rs.getDouble("cantidad"));

                    dp.setPrecio_unitario(
                            rs.getDouble("precio_unitario"));

                    dp.setDescuento(
                            rs.getDouble("descuento"));

                    dp.setSubtotal(
                            rs.getDouble("subtotal"));

                    lista.add(dp);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}