package com.demografia.dao.interfaces;




import com.demografia.model.ConsumoMateriaPrima;

import java.util.List;


public interface IConsumoMateriaPrima {
    void registrar(ConsumoMateriaPrima consumoMateriaPrima);
    void modificar(ConsumoMateriaPrima consumoMateriaPrima);
    void eliminar(Integer id);
    ConsumoMateriaPrima obtenerPorId(Integer id);
    List<ConsumoMateriaPrima> listarTodos();
}