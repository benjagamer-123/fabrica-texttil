package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IEtapaProduccion;
import com.demografia.model.EtapaProduccion;

public class EtapaProduccionDAOImpl implements IEtapaProduccion {

    @Override
    public void registrar(EtapaProduccion ep) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "id_orden_prod, nombre_etapa, orden_secuencia, estado, fecha_inicio_real, fecha_fin_real";
        String vals = "'" + ep.getId_orden_prod() + "', '" + ep.getNombre_etapa() + "', '" + ep.getOrden_secuencia() + "', '" + ep.getEstado() + "', '" + ep.getFecha_inicio_real() + "', '" + ep.getFecha_fin_real() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "etapas_produccion");
            cst.setString(2, cols);
            cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(EtapaProduccion ep) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "id_orden_prod='" + ep.getId_orden_prod() + "', nombre_etapa='" + ep.getNombre_etapa() + "', orden_secuencia='" + ep.getOrden_secuencia() + "', estado='" + ep.getEstado() + "', fecha_inicio_real='" + ep.getFecha_inicio_real() + "', fecha_fin_real='" + ep.getFecha_fin_real() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "etapas_produccion");
            cst.setString(2, sets);
            cst.setInt(3, ep.getId_etapa());
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "etapas_produccion");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public EtapaProduccion obtenerPorId(Integer id) {
        for (EtapaProduccion item : listarTodos()) {
            if (item.getId_etapa() == id) return item;
        }
        return null;
    }

    @Override
    public List<EtapaProduccion> listarTodos() {
        List<EtapaProduccion> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "etapas_produccion");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    EtapaProduccion ep = new EtapaProduccion();
                    ep.setId_etapa(rs.getInt("id_etapa"));
                    ep.setId_orden_prod(rs.getInt("id_orden_prod"));
                    ep.setNombre_etapa(rs.getString("nombre_etapa"));
                    ep.setOrden_secuencia(rs.getInt("orden_secuencia"));
                    ep.setEstado(rs.getString("estado"));
                    ep.setFecha_inicio_real(rs.getString("fecha_inicio_real"));
                    ep.setFecha_fin_real(rs.getString("fecha_fin_real"));
                    lista.add(ep);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}