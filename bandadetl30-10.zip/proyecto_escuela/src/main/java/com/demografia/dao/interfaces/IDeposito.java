package com.demografia.dao.interfaces;
import com.demografia.model.Deposito;


import java.util.List;


public interface IDeposito {
    void registrar(Deposito d);
    void modificar(Deposito d);
    void eliminar(int id);
    Deposito obtenerPorId(int id);
    List<Deposito> listarTodos();
}
