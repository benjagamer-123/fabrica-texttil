package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.DetallePedido;

public interface IDetallePedido {
    void registrar(DetallePedido detallePedido);
    void modificar(DetallePedido detallePedido);
    void eliminar(Integer id);
    DetallePedido obtenerPorId(Integer id);
    List<DetallePedido> listarTodos();
}
