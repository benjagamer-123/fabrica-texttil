package com.demografia.dao.interfaces;


import java.util.List;

import com.demografia.model.Permiso;

public interface IPermiso {
    void registrar(Permiso permiso);
    void modificar(Permiso permiso);
    void eliminar(Integer id);
    Permiso obtenerPorId(Integer id);
    List<Permiso> listarTodos();
}
