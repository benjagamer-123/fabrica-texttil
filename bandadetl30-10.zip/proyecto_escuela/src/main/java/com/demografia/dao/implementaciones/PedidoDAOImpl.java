package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IPedido;
import com.demografia.model.Pedido;

public class PedidoDAOImpl implements IPedido {

    @Override
    public void registrar(Pedido p) {

        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";

        String cols = "id_cliente, fecha_pedido, estado, fecha_entrega_req, observaciones, total_estimado, id_producto";

        String vals = "'" + p.getId_cliente() + "', NOW(), '"
                + p.getEstado() + "', '"
                + p.getFecha_entrega_req() + "', '"
                + p.getObservaciones() + "', '"
                + p.getTotal_estimado() + "', '"
                + p.getId_producto() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "pedidos");
            cst.setString(2, cols);
            cst.setString(3, vals);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Pedido p) {

        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";

        String sets = "id_cliente='" + p.getId_cliente()
                + "', estado='" + p.getEstado()
                + "', fecha_entrega_req='" + p.getFecha_entrega_req()
                + "', observaciones='" + p.getObservaciones()
                + "', total_estimado='" + p.getTotal_estimado()
                + "', id_producto='" + p.getId_producto() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "pedidos");
            cst.setString(2, sets);
            cst.setInt(3, p.getId_pedido());

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {

        String sql = "{CALL sp_eliminar_por_id(?, ?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "pedidos");
            cst.setInt(2, id);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Pedido obtenerPorId(Integer id) {

        for (Pedido item : listarTodos()) {

            if (item.getId_pedido() == id) {
                return item;
            }
        }

        return null;
    }

    @Override
    public List<Pedido> listarTodos() {

        List<Pedido> lista = new ArrayList<>();

        String sql = "{CALL mostrar(?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "pedidos");

            try (ResultSet rs = cst.executeQuery()) {

                while (rs.next()) {

                    Pedido p = new Pedido();

                    p.setId_pedido(rs.getInt("id_pedido"));
                    p.setId_cliente(rs.getInt("id_cliente"));
                    p.setFecha_pedido(rs.getString("fecha_pedido"));
                    p.setEstado(rs.getString("estado"));
                    p.setFecha_entrega_req(rs.getString("fecha_entrega_req"));
                    p.setObservaciones(rs.getString("observaciones"));
                    p.setTotal_estimado(rs.getDouble("total_estimado"));
                    p.setId_producto(rs.getInt("id_producto"));

                    lista.add(p);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}