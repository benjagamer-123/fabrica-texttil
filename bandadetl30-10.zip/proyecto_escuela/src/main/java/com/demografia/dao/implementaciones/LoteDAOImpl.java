package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.ILote;
import com.demografia.model.Lote;

public class LoteDAOImpl implements ILote {

    @Override
    public void registrar(Lote l) {

        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";

        String cols = "id_orden_prod, nombre_etapa, orden_secuencia, estado, fecha_inicio_real, fecha_fin_real";

        Integer idOrdenProd = (l.getOrdenProduccion() != null)
                ? l.getOrdenProduccion().getId_orden_prod()
                : null;

        String vals = "'" + idOrdenProd + "', '"
                + l.getNombreEtapa() + "', '"
                + l.getOrdenSecuencia() + "', '"
                + l.getEstado() + "', '"
                + l.getFechaInicioReal() + "', '"
                + l.getFechaFinReal() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "lotes");
            cst.setString(2, cols);
            cst.setString(3, vals);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Lote l) {

        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";

        Integer idOrdenProd = (l.getOrdenProduccion() != null)
                ? l.getOrdenProduccion().getId_orden_prod()
                : null;

        String sets = "id_orden_prod='" + idOrdenProd
                + "', nombre_etapa='" + l.getNombreEtapa()
                + "', orden_secuencia='" + l.getOrdenSecuencia()
                + "', estado='" + l.getEstado()
                + "', fecha_inicio_real='" + l.getFechaInicioReal()
                + "', fecha_fin_real='" + l.getFechaFinReal() + "'";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "lotes");
            cst.setString(2, sets);
            cst.setInt(3, l.getIdEtapa());

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {

        String sql = "{CALL sp_eliminar_por_id(?, ?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "lotes");
            cst.setInt(2, id);

            cst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Lote obtenerPorId(Integer id) {

        for (Lote item : listarTodos()) {

            if (item.getIdEtapa() != null
                    && item.getIdEtapa().equals(id)) {

                return item;
            }
        }

        return null;
    }

    @Override
    public List<Lote> listarTodos() {

        List<Lote> lista = new ArrayList<>();

        String sql = "{CALL mostrar(?)}";

        try (Connection con = Conexion.getConnection();
             CallableStatement cst = con.prepareCall(sql)) {

            cst.setString(1, "lotes");

            try (ResultSet rs = cst.executeQuery()) {

                while (rs.next()) {

                    Lote l = new Lote();

                    l.setIdEtapa(rs.getInt("id_etapa"));
                    l.setNombreEtapa(rs.getString("nombre_etapa"));
                    l.setOrdenSecuencia(rs.getInt("orden_secuencia"));
                    l.setEstado(rs.getString("estado"));

                    if (rs.getTimestamp("fecha_inicio_real") != null) {
                        l.setFechaInicioReal(
                                rs.getTimestamp("fecha_inicio_real")
                                  .toLocalDateTime()
                        );
                    }

                    if (rs.getTimestamp("fecha_fin_real") != null) {
                        l.setFechaFinReal(
                                rs.getTimestamp("fecha_fin_real")
                                  .toLocalDateTime()
                        );
                    }

                    lista.add(l);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}