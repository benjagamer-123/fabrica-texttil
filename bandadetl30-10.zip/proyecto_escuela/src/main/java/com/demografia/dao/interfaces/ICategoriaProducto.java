package com.demografia.dao.interfaces;


import com.demografia.model.CategoriaProducto;

import java.util.List;
public interface ICategoriaProducto {
    void registrar(CategoriaProducto categoriaProducto);
    void modificar(CategoriaProducto categoriaProducto);
    void eliminar(Integer id);
    CategoriaProducto obtenerPorId(Integer id);
    List<CategoriaProducto> listarTodos();
}
