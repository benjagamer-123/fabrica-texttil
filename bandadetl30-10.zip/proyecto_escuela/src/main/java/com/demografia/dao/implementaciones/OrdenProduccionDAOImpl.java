package com.demografia.dao.implementaciones;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IOrdenProduccion;
import com.demografia.model.OrdenProduccion;

public class OrdenProduccionDAOImpl implements IOrdenProduccion {
	@Override
    public void registrar(OrdenProduccion op) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "numero_orden, fecha_inicio_est, fecha_fin_est, estado, id_responsable, observaciones";
        String vals = "'" + op.getNumero_orden() + "', '" + op.getFecha_inicio_est() + "', '" + op.getFecha_fin_est() + "', '" + op.getEstado() + "', '" + op.getId_responsable() + "', '" + op.getObservaciones() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "ordenes_produccion");
            cst.setString(2, cols);
            cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	@Override
    public void modificar(OrdenProduccion op) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "numero_orden='" + op.getNumero_orden() + "', fecha_inicio_est='" + op.getFecha_inicio_est() + "', fecha_fin_est='" + op.getFecha_fin_est() + "', estado='" + op.getEstado() + "', id_responsable='" + op.getId_responsable() + "', observaciones='" + op.getObservaciones() + "'";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "ordenes_produccion");
            cst.setString(2, sets);
            cst.setInt(3, op.getId_orden_prod());
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	@Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "ordenes_produccion");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	@Override
    public OrdenProduccion obtenerPorId(Integer id) {
        for (OrdenProduccion item : listarTodos()) {
            if (item.getId_orden_prod() == id) return item;
        }
        return null;
    }
	@Override
    public List<OrdenProduccion> listarTodos() {
        List<OrdenProduccion> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "ordenes_produccion");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    OrdenProduccion op = new OrdenProduccion();
                    op.setId_orden_prod(rs.getInt("id_orden_prod"));
                    op.setNumero_orden(rs.getString("numero_orden"));
                    op.setFecha_inicio_est(rs.getString("fecha_inicio_est"));
                    op.setFecha_fin_est(rs.getString("fecha_fin_est"));
                    op.setEstado(rs.getString("estado"));
                    op.setId_responsable(rs.getInt("id_responsable"));
                    op.setObservaciones(rs.getString("observaciones"));
                    lista.add(op);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}