package com.demografia.controller;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;


@WebServlet("/testdb")
public class TestDB extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        
        Connection conn = com.demografia.config.Conexion.getConnection();
        
        if (conn != null) {
            resp.getWriter().println("¡Conesión con la DB exitosa!");
        } else {
            resp.getWriter().println("No se pudo conectar con la DB.");
        }
    }
}
