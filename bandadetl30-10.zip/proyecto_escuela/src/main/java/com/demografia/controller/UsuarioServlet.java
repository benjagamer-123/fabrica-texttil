package com.demografia.controller;

import java.io.IOException;
import java.util.List;

import com.demografia.dao.implementaciones.UsuarioDAOImpl;
import com.demografia.dao.interfaces.IUsuario;
import com.demografia.model.Usuario;
import com.fasterxml.jackson.databind.ObjectMapper;


import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/usuario")
public class UsuarioServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private IUsuario dao = new UsuarioDAOImpl();
    private ObjectMapper mapper = new ObjectMapper(); 

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json"); 
        resp.setCharacterEncoding("UTF-8");
        
        String action = req.getParameter("action");
        
        switch (action != null ? action.toLowerCase() : "") {
            case "list":
                List<Usuario> usuarios = dao.listarTodos();
                resp.getWriter().write(mapper.writeValueAsString(usuarios));
                break;
                
            case "find":
                String idParam = req.getParameter("id");
                if (idParam != null) {
                    int id = Integer.parseInt(idParam);
                    Usuario usuario = dao.obtenerPorId(id);
                    if (usuario != null) {
                        resp.getWriter().write(mapper.writeValueAsString(usuario));
                    } else {
                        resp.getWriter().write("{\"message\":\"Usuario no encontrado\"}");
                    }
                } else {
                    resp.getWriter().write("{\"message\":\"ID requerido\"}");
                }
                break;
                
            default:
                resp.getWriter().write("{\"message\":\"Acción GET no válida\"}");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String action = req.getParameter("action");
        
        switch (action != null ? action.toLowerCase() : "") {
            case "add":
                String nombre = req.getParameter("nombre");
                String email = req.getParameter("email");
                String password = req.getParameter("password");
                
                if (nombre != null && email != null && password != null) {
                    Usuario nuevo = new Usuario();
                    nuevo.setNombre(nombre);
                    nuevo.setEmail(email);
                    nuevo.setPassword_hash(password);
                    nuevo.setEstado("Activo"); 
                    nuevo.setId_rol(1);        
                    
                    boolean added = dao.registrar(nuevo); 
                    resp.getWriter().write("{\"success\":" + added + "}");
                } else {
                    resp.getWriter().write("{\"message\":\"Campos obligatorios faltantes\"}");
                }
                break;
                
            default:
                resp.getWriter().write("{\"message\":\"Acción POST no válida\"}");
                break;
        }
    }
}
