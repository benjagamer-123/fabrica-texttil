package com.demografia.dao.factory;

import com.demografia.dao.implementaciones.UsuarioDAOImpl;
import com.demografia.dao.interfaces.IUsuario;

public class DAOFactory {

    public static IUsuario getUsuarioDAO() {
        return new UsuarioDAOImpl();
    }

}
