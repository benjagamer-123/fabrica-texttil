package com.demografia.dao.interfaces;


import java.util.List; 

import com.demografia.model.CategoriaProducto;
import com.demografia.model.Cliente;


public interface ICliente {
    void registrar(Cliente cliente);
    void modificar(Cliente cliente);
    void eliminar(Integer id);
    Cliente obtenerPorId(Integer id);
    List<Cliente> listarTodos();
	String getCuit();
	String getRazon_social();
	String getTipo_cliente();
	String getEmail();
	String getTelefono();
	String getDireccion();
	String getId_pais();
	String getCiudad();
	String getEstado();
	void registrar(ICliente c);

	
}
