package com.demografia.controler;

import com.demografia.dao.implementaciones.UsuarioDAOImpl;
import com.demografia.dao.interfaces.IUsuario;
import com.demografia.model.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/api/usuarios")
public class UsuarioServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final IUsuario usuarioDao = new UsuarioDAOImpl();

    // ========================================================
    // GET: Listar todos o buscar por ID (Sin librerías externas)
    // ========================================================
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        
        try {
            if (idParam != null && !idParam.isEmpty()) {
                Integer id = Integer.parseInt(idParam);
                Usuario u = usuarioDao.obtenerPorId(id);
                
                if (u != null) {
                    resp.setStatus(HttpServletResponse.SC_OK);
                    // Armamos el JSON manualmente usando los getters de tu clase Usuario
                    String json = "{"
                            + "\"id_usuario\":" + u.getId_usuario() + ","
                            + "\"nombre\":\"" + u.getNombre() + "\","
                            + "\"email\":\"" + u.getEmail() + "\","
                            + "\"estado\":\"" + u.getEstado() + "\","
                            + "\"id_rol\":" + u.getId_rol()
                            + "}";
                    resp.getWriter().write(json);
                } else {
                    resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    resp.getWriter().write("{\"error\":\"Usuario no encontrado\"}");
                }
            } else {
                List<Usuario> lista = usuarioDao.listarTodos();
                resp.setStatus(HttpServletResponse.SC_OK);
                
                // Construimos la lista en formato JSON de forma nativa
                StringBuilder sb = new StringBuilder();
                sb.append("[");
                for (int i = 0; i < lista.size(); i++) {
                    Usuario u = lista.get(i);
                    sb.append("{")
                      .append("\"id_usuario\":").append(u.getId_usuario()).append(",")
                      .append("\"nombre\":\"").append(u.getNombre()).append("\",")
                      .append("\"email\":\"").append(u.getEmail()).append("\",")
                      .append("\"estado\":\"").append(u.getEstado()).append("\",")
                      .append("\"id_rol\":").append(u.getId_rol())
                      .append("}");
                    if (i < lista.size() - 1) {
                        sb.append(",");
                    }
                }
                sb.append("]");
                
                resp.getWriter().write(sb.toString());
            }
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }
}
