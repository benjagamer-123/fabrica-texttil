package com.demografia.controler;

import java.io.IOException;
import java.sql.Connection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/testdb")
public class TestDB extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        
        Connection conn = com.demografia.config.Conexion.getConnection();
        
        if (conn != null) {
            resp.getWriter().println("¡Conexion con la DB exitosa!");
        } else {
            resp.getWriter().println("No se pudo conectar con la DB.");
        }
    }
}
