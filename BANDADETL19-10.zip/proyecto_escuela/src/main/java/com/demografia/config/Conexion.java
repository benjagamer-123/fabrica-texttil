package com.demografia.config;

import java.sql.Connection; 
import java.sql.DriverManager;

public class Conexion {
    private static final String URL = "jdbc:mysql://localhost:3306/bandadetl";
    private static final String USER = "root";
    private static final String PASS = "";

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (Exception e) {
            System.out.println("Error conexión: " + e.getMessage());
            e.printStackTrace(); // Esto te mostrará el detalle exacto del error en la consola si falla
            return null;
        }
    }
}
