package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IUsuario;
import com.demografia.model.Usuario;

public class UsuarioDAOImpl implements IUsuario {

	@Override
	public void registrar(Usuario u) {
	    String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
	    String cols = "nombre, email, password_hash, estado, id_rol";
	    
	    // CORRECCIÓN SINTÁCTICA CRUCIAL:
	    // Envolvemos los textos individuales usando caracteres de escape (\') 
	    // y dejamos el id_rol al final como un número limpio, sin comillas.
	    String vals = "\'" + u.getNombre() + "\', \'" + u.getEmail() + "\', \'" + u.getPassword_hash() + "\', \'" 
	                + u.getEstado() + "\', " + u.getId_rol();
	                
	    try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
	        cst.setString(1, "usuarios");
	        cst.setString(2, cols);
	        cst.setString(3, vals);
	        
	        cst.executeUpdate();
	        System.out.println("=== STORED PROCEDURE EJECUTADO EN JAVA ===");
	        
	    } catch (SQLException e) {
	        System.err.println("=== ERROR REAL DETECTADO EN EL STORED PROCEDURE ===");
	        System.err.println("Mensaje de MySQL: " + e.getMessage());
	        e.printStackTrace();
	    }
	}


    @Override
    public void modificar(Usuario u) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        
        // CORRECCIÓN: Se eliminan las comillas simples del id_rol al final de la asignación dinámica
        String sets = "nombre='" + u.getNombre() + "', email='" + u.getEmail() 
                    + "', password_hash='" + u.getPassword_hash() + "', estado='" + u.getEstado() 
                    + "', id_rol=" + u.getId_rol();
                    
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "usuarios");
            cst.setString(2, sets);
            cst.setInt(3, u.getId_usuario());
            cst.executeUpdate();
        } catch (SQLException e) {
            System.err.println("=== ERROR EN DAO AL MODIFICAR USUARIO ===");
            System.err.println("Mensaje: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "usuarios");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            System.err.println("=== ERROR EN DAO AL ELIMINAR USUARIO ===");
            System.err.println("Mensaje: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public Usuario obtenerPorId(Integer id) {
        for (Usuario item : listarTodos()) {
            if (item.getId_usuario() == id) return item;
        }
        return null;
    }

    @Override
    public List<Usuario> listarTodos() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "usuarios");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    Usuario u = new Usuario();
                    u.setId_usuario(rs.getInt("id_usuario"));
                    u.setNombre(rs.getString("nombre"));
                    u.setEmail(rs.getString("email"));
                    u.setPassword_hash(rs.getString("password_hash"));
                    u.setEstado(rs.getString("estado"));
                    u.setId_rol(rs.getInt("id_rol"));
                    lista.add(u);
                }
            }
        } catch (SQLException e) {
            System.err.println("=== ERROR EN DAO AL LISTAR TODOS LOS USUARIOS ===");
            System.err.println("Mensaje: " + e.getMessage());
            e.printStackTrace();
        }
        return lista;
    }
}
