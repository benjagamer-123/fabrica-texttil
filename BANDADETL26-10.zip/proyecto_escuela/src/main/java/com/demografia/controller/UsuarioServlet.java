package com.demografia.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.demografia.model.Usuario;
import com.demografia.dao.interfaces.IUsuario;
import com.demografia.dao.implementaciones.UsuarioDAOImpl;

@WebServlet("/usuario") 
public class UsuarioServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // 1. EL GET: Modificado para mostrar el formato exacto que me pediste
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/plain;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            IUsuario usuarioDao = new UsuarioDAOImpl();
            List<Usuario> lista = usuarioDao.listarTodos(); 
            
            if (lista == null || lista.isEmpty()) {
                out.println("=== USUARIOS LISTADOS EN LA BD ===");
                out.println("----------------------------------");
                out.println("No hay usuarios registrados en la base de datos.");
            } else {
                out.println("=== USUARIOS LISTADOS EN LA BD ===");
                out.println("----------------------------------");
                for (Usuario u : lista) {
                    // Formato exacto solicitado
                    out.println("usuario: " + u.getNombre());
                    out.println("correo: " + u.getEmail());
                    out.println("contraseña: " + u.getPassword_hash());
                    out.println("----------------------------------");
                }
            }
        } catch (Exception e) {
            out.println("Error al consultar la base de datos: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // 2. EL POST: Corregido para asegurar que 'estado' e 'id_rol' lleven valores válidos a tu DAO
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/plain;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String nombre = request.getParameter("nombre");
        String email = request.getParameter("email");
        String password = request.getParameter("password"); 
        String estado = request.getParameter("estado");       
        String idRolStr = request.getParameter("id_rol");     
        
        if (nombre != null && email != null && password != null) {
            try {
                IUsuario usuarioDao = new UsuarioDAOImpl();
                
                Usuario nuevoUsuario = new Usuario();
                nuevoUsuario.setNombre(nombre);
                nuevoUsuario.setEmail(email);
                nuevoUsuario.setPassword_hash(password); 
                
                // Corrección crucial para evitar enviar 'null' como texto a tu consulta dinámica
                nuevoUsuario.setEstado(estado != null ? estado : "Activo");
                nuevoUsuario.setId_rol(idRolStr != null ? Integer.parseInt(idRolStr) : 1);
                
                // Ejecuta tu procedimiento almacenado
                usuarioDao.registrar(nuevoUsuario); 
                
                out.println("¡Procedimiento de registro ejecutado con éxito!");
                out.println("Se enviaron los datos a la tabla usuarios:");
                out.println("Nombre: " + nombre + " | Email: " + email);
                
            } catch (Exception e) {
                out.println("Error al insertar en la base de datos: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            out.println("Error: Faltan parámetros obligatorios (nombre, email o password) en el Body de Postman.");
        }
    }
}
