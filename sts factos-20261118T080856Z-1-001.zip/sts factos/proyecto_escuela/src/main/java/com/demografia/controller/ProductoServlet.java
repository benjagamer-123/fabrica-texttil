package com.demografia.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.demografia.dao.interfaces.IProducto;
import com.demografia.factory.factory;
import com.demografia.model.Producto;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebServlet("/producto")
public class ProductoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private IProducto dao = factory.getProductoDao();
    private ObjectMapper mapper = new ObjectMapper();

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if ("PATCH".equalsIgnoreCase(req.getMethod())) {
            doPatch(req, resp);
        } else {
            super.service(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");
        if (action == null) action = "list";
        switch (action.toLowerCase()) {
            case "buscar":
                String idStr = req.getParameter("id");
                if (idStr != null) {
                    Producto p = dao.obtenerPorId(Integer.parseInt(idStr));
                    resp.getWriter().write(mapper.writeValueAsString(p));
                }
                break;
            case "list":
            default:
                List<Producto> lista = dao.listarTodos();
                resp.getWriter().write(mapper.writeValueAsString(lista));
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        Producto p = mapper.readValue(req.getReader(), Producto.class);
        dao.registrar(p);
        resp.getWriter().write("{\"mensaje\": \"Producto registrado exitosamente\"}");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        Producto p = mapper.readValue(req.getReader(), Producto.class);
        dao.modificar(p);
        resp.getWriter().write("{\"mensaje\": \"Producto actualizado exitosamente\"}");
    }

    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String idStr = req.getParameter("id");
        if (idStr != null) {
            // Ideal para actualizar sólo el precio o el estado del producto
            resp.getWriter().write("{\"mensaje\": \"Precio o datos del producto actualizados parcialmente\"}");
        } else {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"Se requiere el parámetro id para PATCH\"}");
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String idStr = req.getParameter("id");
        if (idStr != null) {
            dao.eliminar(Integer.parseInt(idStr));
            resp.getWriter().write("{\"mensaje\": \"Producto eliminado exitosamente\"}");
        } else {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"Se requiere el parámetro id\"}");
        }
    }
}