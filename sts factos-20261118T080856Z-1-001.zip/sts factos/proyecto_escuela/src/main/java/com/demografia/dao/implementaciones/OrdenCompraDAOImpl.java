package com.demografia.dao.implementaciones;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demografia.config.Conexion;
import com.demografia.dao.interfaces.IOrdenCompra;
import com.demografia.model.OrdenCompra;

public class OrdenCompraDAOImpl implements IOrdenCompra {

    @Override
    public void registrar(OrdenCompra oc) {
        String sql = "{CALL sp_insertar_dinamico(?, ?, ?)}";
        String cols = "fecha_orden, estado, id_proveedor, total_estimado, precio, cantidad";
        String vals = "'" + oc.getFecha_orden() + "', '" + oc.getEstado() + "', " + oc.getId_proveedor() + ", " + oc.getTotal_estimado() + ", " + oc.getPrecio() + ", " + oc.getCantidad();
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "ordenes_compra");
            cst.setString(2, cols);
            cst.setString(3, vals);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(OrdenCompra oc) {
        String sql = "{CALL sp_actualizar_dinamico(?, ?, ?)}";
        String sets = "fecha_orden='" + oc.getFecha_orden() + "', estado='" + oc.getEstado() + "', id_proveedor=" + oc.getId_proveedor() + ", total_estimado=" + oc.getTotal_estimado() + ", precio=" + oc.getPrecio() + ", cantidad=" + oc.getCantidad();
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "ordenes_compra");
            cst.setString(2, sets);
            cst.setInt(3, oc.getId_orden_compra());
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer id) {
        String sql = "{CALL sp_eliminar_por_id(?, ?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "ordenes_compra");
            cst.setInt(2, id);
            cst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public OrdenCompra obtenerPorId(Integer id) {
        for (OrdenCompra item : listarTodos()) {
            if (item.getId_orden_compra() == id) return item;
        }
        return null;
    }

    @Override
    public List<OrdenCompra> listarTodos() {
        List<OrdenCompra> lista = new ArrayList<>();
        String sql = "{CALL mostrar(?)}";
        try (Connection con = Conexion.getConnection(); CallableStatement cst = con.prepareCall(sql)) {
            cst.setString(1, "ordenes_compra");
            try (ResultSet rs = cst.executeQuery()) {
                while (rs.next()) {
                    OrdenCompra oc = new OrdenCompra();
                    oc.setId_orden_compra(rs.getInt("id_orden_compra"));
                    oc.setFecha_orden(rs.getString("fecha_orden"));
                    oc.setEstado(rs.getString("estado"));
                    oc.setId_proveedor(rs.getInt("id_proveedor"));
                    oc.setTotal_estimado(rs.getDouble("total_estimado"));
                    oc.setPrecio(rs.getDouble("precio"));
                    oc.setCantidad(rs.getInt("cantidad"));
                    lista.add(oc);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}