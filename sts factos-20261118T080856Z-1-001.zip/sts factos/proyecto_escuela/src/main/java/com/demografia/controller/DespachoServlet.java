package com.demografia.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.demografia.dao.interfaces.IDespacho;
import com.demografia.factory.factory;
import com.demografia.model.Despacho;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebServlet("/despacho")
public class DespachoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Instanciación limpia aplicando el Patrón Factory
    private IDespacho dao = factory.getDespachoDao();
    private ObjectMapper mapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        String action = req.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action.toLowerCase()) {
            case "buscar":
                String idStr = req.getParameter("id");
                if (idStr != null) {
                    Despacho d = dao.obtenerPorId(Integer.parseInt(idStr));
                    resp.getWriter().write(mapper.writeValueAsString(d));
                }
                break;
            case "list":
            default:
                List<Despacho> lista = dao.listarTodos();
                resp.getWriter().write(mapper.writeValueAsString(lista));
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        Despacho d = mapper.readValue(req.getReader(), Despacho.class);
        dao.registrar(d);
        resp.getWriter().write("{\"mensaje\": \"Despacho registrado exitosamente\"}");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        Despacho d = mapper.readValue(req.getReader(), Despacho.class);
        dao.modificar(d);
        resp.getWriter().write("{\"mensaje\": \"Despacho actualizado exitosamente\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        String idStr = req.getParameter("id");
        if (idStr != null) {
            dao.eliminar(Integer.parseInt(idStr));
            resp.getWriter().write("{\"mensaje\": \"Despacho eliminado exitosamente\"}");
        } else {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"Se requiere el parámetro id\"}");
        }
    }
}