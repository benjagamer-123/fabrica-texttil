package com.demografia.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.demografia.config.Conexion;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * API genérica del panel de administración (listar / insertar / editar / eliminar)
 * para cualquier tabla de la base. Los nombres de tablas y columnas se validan
 * contra los metadatos de la base, nunca se concatenan valores del usuario al SQL.
 * Solo accesible con rol 1 (AdminFilter + chequeo propio).
 *
 * GET  ?action=tables
 * GET  ?action=schema&table=X
 * GET  ?action=list&table=X
 * POST ?action=insert&table=X   body {"values":{...}}
 * POST ?action=update&table=X   body {"pk":{...},"values":{...}}
 * POST ?action=delete&table=X   body {"pk":{...}}
 */
@WebServlet("/admin/api")
public class AdminApiServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final int MAX_FILAS = 1000;
    private static final String MASCARA = "********";

    private final ObjectMapper mapper = new ObjectMapper();

    // ---------- tipos internos ----------
    private static class ErrorApi extends Exception {
        private static final long serialVersionUID = 1L;
        final int status;
        ErrorApi(int status, String msg) { super(msg); this.status = status; }
    }

    private static class Columna {
        String nombre, tipo;
        boolean nullable, autoInc, pk, secreta, tieneDefault;
        int tam;

        boolean esTexto() {
            String t = tipo.toUpperCase();
            return t.contains("CHAR") || t.contains("TEXT") || t.contains("ENUM") || t.contains("SET");
        }

        Map<String, Object> aMapa() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", nombre);
            m.put("type", tipo);
            m.put("size", tam);
            m.put("nullable", nullable);
            m.put("autoIncrement", autoInc);
            m.put("pk", pk);
            m.put("secret", secreta);
            m.put("hasDefault", tieneDefault);
            return m;
        }
    }

    private static class Esquema {
        String tabla;
        List<Columna> columnas = new ArrayList<>();
        List<String> pk = new ArrayList<>();
        Map<String, Map<String, String>> fks = new LinkedHashMap<>();

        Columna col(String nombre) {
            for (Columna c : columnas) if (c.nombre.equals(nombre)) return c;
            return null;
        }

        Map<String, Object> aMapa() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("table", tabla);
            List<Map<String, Object>> cols = new ArrayList<>();
            for (Columna c : columnas) cols.add(c.aMapa());
            m.put("columns", cols);
            m.put("pk", pk);
            m.put("fks", fks);
            return m;
        }
    }

    // ---------- entrada ----------
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Cache-Control", "no-store");
        if (!AdminFilter.esAdmin(req)) {
            responder(resp, 403, mapa("error", "Acceso solo para administradores"));
            return;
        }
        super.service(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        procesar(req, resp, false);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        procesar(req, resp, true);
    }

    private void procesar(HttpServletRequest req, HttpServletResponse resp, boolean post) throws IOException {
        String action = req.getParameter("action") == null ? "" : req.getParameter("action").toLowerCase();
        try (Connection c = Conexion.getConnection()) {
            if (c == null) throw new ErrorApi(500, "No se pudo conectar a la base de datos");
            Object r = post ? manejarPost(c, req, action) : manejarGet(c, req, action);
            responder(resp, 200, r);
        } catch (ErrorApi e) {
            responder(resp, e.status, mapa("error", e.getMessage()));
        } catch (SQLException e) {
            responder(resp, 400, mapa("error", mensajeSql(e)));
        } catch (IOException e) {
            responder(resp, 400, mapa("error", "Cuerpo de la petición inválido"));
        }
    }

    // ---------- GET ----------
    private Object manejarGet(Connection c, HttpServletRequest req, String action) throws SQLException, ErrorApi {
        switch (action) {
            case "tables":
                return listarTablas(c);
            case "schema":
                return esquema(c, validarTabla(c, req.getParameter("table"))).aMapa();
            case "list":
                return listar(c, esquema(c, validarTabla(c, req.getParameter("table"))));
            default:
                throw new ErrorApi(400, "Acción GET no válida");
        }
    }

    private Object listar(Connection c, Esquema e) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT * FROM `").append(e.tabla).append('`');
        if (!e.pk.isEmpty()) sql.append(" ORDER BY `").append(e.pk.get(0)).append("` DESC");
        sql.append(" LIMIT ").append(MAX_FILAS + 1);

        List<Map<String, String>> filas = new ArrayList<>();
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql.toString())) {
            ResultSetMetaData md = rs.getMetaData();
            while (rs.next()) {
                Map<String, String> fila = new LinkedHashMap<>();
                for (int i = 1; i <= md.getColumnCount(); i++) {
                    String nombre = md.getColumnLabel(i);
                    String v = rs.getString(i);
                    Columna col = e.col(nombre);
                    if (v != null && col != null && col.secreta) v = MASCARA;
                    fila.put(nombre, v);
                }
                filas.add(fila);
            }
        }
        boolean truncado = filas.size() > MAX_FILAS;
        if (truncado) filas.remove(filas.size() - 1);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("rows", filas);
        out.put("truncated", truncado);
        return out;
    }

    // ---------- POST ----------
    @SuppressWarnings("unchecked")
    private Object manejarPost(Connection c, HttpServletRequest req, String action) throws SQLException, ErrorApi, IOException {
        Esquema e = esquema(c, validarTabla(c, req.getParameter("table")));
        Map<String, Object> cuerpo = mapper.readValue(req.getReader(), new TypeReference<Map<String, Object>>() {});
        Map<String, String> values = aTexto((Map<String, Object>) cuerpo.get("values"));
        Map<String, String> pk = aTexto((Map<String, Object>) cuerpo.get("pk"));

        switch (action) {
            case "insert":
                return insertar(c, e, values);
            case "update":
                return actualizar(c, req, e, pk, values);
            case "delete":
                return eliminar(c, req, e, pk);
            default:
                throw new ErrorApi(400, "Acción POST no válida");
        }
    }

    private Object insertar(Connection c, Esquema e, Map<String, String> values) throws SQLException {
        List<String> cols = new ArrayList<>();
        List<String> vals = new ArrayList<>();
        for (Columna col : e.columnas) {
            if (!values.containsKey(col.nombre)) continue;
            String v = values.get(col.nombre);
            boolean vacio = v == null || v.isEmpty();
            if (vacio) {
                if (col.autoInc || col.tieneDefault) continue;   // que lo resuelva la base
                if (col.nullable) { cols.add(col.nombre); vals.add(null); continue; }
                if (col.esTexto()) { cols.add(col.nombre); vals.add(""); }
                continue;
            }
            cols.add(col.nombre);
            vals.add(v);
        }

        StringBuilder sql = new StringBuilder("INSERT INTO `").append(e.tabla).append('`');
        if (cols.isEmpty()) {
            sql.append(" () VALUES ()");
        } else {
            sql.append(" (");
            StringBuilder ph = new StringBuilder();
            for (int i = 0; i < cols.size(); i++) {
                if (i > 0) { sql.append(", "); ph.append(", "); }
                sql.append('`').append(cols.get(i)).append('`');
                ph.append('?');
            }
            sql.append(") VALUES (").append(ph).append(')');
        }

        try (PreparedStatement ps = c.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS)) {
            for (int i = 0; i < vals.size(); i++) ps.setObject(i + 1, vals.get(i));
            ps.executeUpdate();
            Object id = null;
            try (ResultSet k = ps.getGeneratedKeys()) { if (k.next()) id = k.getString(1); }
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("success", true);
            out.put("id", id);
            return out;
        }
    }

    private Object actualizar(Connection c, HttpServletRequest req, Esquema e, Map<String, String> pk,
                              Map<String, String> values) throws SQLException, ErrorApi {
        exigirPk(e, pk);
        protegerUsuarioActual(req, e, pk, values, false);

        List<String> sets = new ArrayList<>();
        List<String> vals = new ArrayList<>();
        for (Columna col : e.columnas) {
            if (col.pk || !values.containsKey(col.nombre)) continue;
            String v = values.get(col.nombre);
            boolean vacio = v == null || v.isEmpty();
            if (vacio) {
                if (col.secreta) continue;                         // contraseña vacía = sin cambios
                if (col.nullable) { sets.add(col.nombre); vals.add(null); }
                else if (col.esTexto()) { sets.add(col.nombre); vals.add(""); }
                continue;
            }
            sets.add(col.nombre);
            vals.add(v);
        }
        if (sets.isEmpty()) throw new ErrorApi(400, "No hay cambios para guardar");

        StringBuilder sql = new StringBuilder("UPDATE `").append(e.tabla).append("` SET ");
        for (int i = 0; i < sets.size(); i++) {
            if (i > 0) sql.append(", ");
            sql.append('`').append(sets.get(i)).append("` = ?");
        }
        agregarWherePk(sql, e);

        try (PreparedStatement ps = c.prepareStatement(sql.toString())) {
            int n = 1;
            for (String v : vals) ps.setObject(n++, v);
            for (String col : e.pk) ps.setObject(n++, pk.get(col));
            int filas = ps.executeUpdate();
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("success", true);
            out.put("rows", filas);
            return out;
        }
    }

    private Object eliminar(Connection c, HttpServletRequest req, Esquema e, Map<String, String> pk)
            throws SQLException, ErrorApi {
        exigirPk(e, pk);
        protegerUsuarioActual(req, e, pk, null, true);

        StringBuilder sql = new StringBuilder("DELETE FROM `").append(e.tabla).append('`');
        agregarWherePk(sql, e);
        try (PreparedStatement ps = c.prepareStatement(sql.toString())) {
            int n = 1;
            for (String col : e.pk) ps.setObject(n++, pk.get(col));
            int filas = ps.executeUpdate();
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("success", filas > 0);
            out.put("rows", filas);
            return out;
        }
    }

    // ---------- utilidades ----------
    private void exigirPk(Esquema e, Map<String, String> pk) throws ErrorApi {
        if (e.pk.isEmpty()) throw new ErrorApi(400, "La tabla no tiene clave primaria: no se puede editar ni eliminar");
        for (String col : e.pk) {
            String v = pk.get(col);
            if (v == null || v.isEmpty()) throw new ErrorApi(400, "Falta la clave primaria: " + col);
        }
    }

    private void agregarWherePk(StringBuilder sql, Esquema e) {
        sql.append(" WHERE ");
        for (int i = 0; i < e.pk.size(); i++) {
            if (i > 0) sql.append(" AND ");
            sql.append('`').append(e.pk.get(i)).append("` = ?");
        }
    }

    /** Evita que el admin se elimine, se desactive o se quite el rol a sí mismo. */
    private void protegerUsuarioActual(HttpServletRequest req, Esquema e, Map<String, String> pk,
                                       Map<String, String> nuevos, boolean eliminar) throws ErrorApi {
        if (!"usuario".equalsIgnoreCase(e.tabla)) return;
        Object yo = req.getSession(false).getAttribute("id_usuario");
        String id = pk.get("id_usuario");
        if (yo == null || id == null || !String.valueOf(yo).equals(id.trim())) return;
        if (eliminar) throw new ErrorApi(400, "No podés eliminar tu propio usuario.");
        if (nuevos != null) {
            String rol = nuevos.get("id_rol");
            if (rol != null && !rol.trim().isEmpty() && !"1".equals(rol.trim()))
                throw new ErrorApi(400, "No podés quitarte tu propio rol de administrador.");
            if ("Inactivo".equalsIgnoreCase(nuevos.get("estado")))
                throw new ErrorApi(400, "No podés desactivar tu propio usuario.");
        }
    }

    private List<String> listarTablas(Connection c) throws SQLException {
        List<String> tablas = new ArrayList<>();
        try (ResultSet rs = c.getMetaData().getTables(c.getCatalog(), null, "%", new String[] { "TABLE" })) {
            while (rs.next()) tablas.add(rs.getString("TABLE_NAME"));
        }
        java.util.Collections.sort(tablas, String.CASE_INSENSITIVE_ORDER);
        return tablas;
    }

    private String validarTabla(Connection c, String pedida) throws SQLException, ErrorApi {
        if (pedida == null || pedida.isEmpty()) throw new ErrorApi(400, "Falta el parámetro table");
        for (String t : listarTablas(c)) if (t.equalsIgnoreCase(pedida)) return t;
        throw new ErrorApi(404, "La tabla no existe");
    }

    private Esquema esquema(Connection c, String tabla) throws SQLException {
        Esquema e = new Esquema();
        e.tabla = tabla;
        DatabaseMetaData md = c.getMetaData();
        String cat = c.getCatalog();

        Map<Integer, String> pks = new TreeMap<>();
        try (ResultSet rs = md.getPrimaryKeys(cat, null, tabla)) {
            while (rs.next()) pks.put(rs.getInt("KEY_SEQ"), rs.getString("COLUMN_NAME"));
        }
        e.pk.addAll(pks.values());

        try (ResultSet rs = md.getColumns(cat, null, tabla, "%")) {
            while (rs.next()) {
                Columna col = new Columna();
                col.nombre = rs.getString("COLUMN_NAME");
                col.tipo = rs.getString("TYPE_NAME");
                col.tam = rs.getInt("COLUMN_SIZE");
                col.nullable = "YES".equalsIgnoreCase(rs.getString("IS_NULLABLE"));
                col.autoInc = "YES".equalsIgnoreCase(rs.getString("IS_AUTOINCREMENT"));
                col.tieneDefault = rs.getString("COLUMN_DEF") != null;
                col.pk = e.pk.contains(col.nombre);
                String n = col.nombre.toLowerCase();
                col.secreta = n.contains("password") || n.contains("contrasen");
                e.columnas.add(col);
            }
        }

        try (ResultSet rs = md.getImportedKeys(cat, null, tabla)) {
            while (rs.next()) {
                Map<String, String> ref = new LinkedHashMap<>();
                ref.put("table", rs.getString("PKTABLE_NAME"));
                ref.put("column", rs.getString("PKCOLUMN_NAME"));
                e.fks.put(rs.getString("FKCOLUMN_NAME"), ref);
            }
        }
        return e;
    }

    private Map<String, String> aTexto(Map<String, Object> origen) {
        Map<String, String> out = new LinkedHashMap<>();
        if (origen == null) return out;
        for (Map.Entry<String, Object> en : origen.entrySet())
            out.put(en.getKey(), en.getValue() == null ? null : String.valueOf(en.getValue()));
        return out;
    }

    private String mensajeSql(SQLException e) {
        int code = e.getErrorCode();
        if (code == 1451) return "No se puede eliminar: el registro está siendo usado por otros datos.";
        if (code == 1452) return "El valor elegido no existe en la tabla relacionada.";
        if (code == 1062) return "Ya existe un registro con ese valor único.";
        if (code == 1048) return "Hay un campo obligatorio vacío.";
        return e.getMessage();
    }

    private Map<String, Object> mapa(String k, Object v) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put(k, v);
        return m;
    }

    private void responder(HttpServletResponse resp, int status, Object cuerpo) throws IOException {
        resp.setStatus(status);
        mapper.writeValue(resp.getWriter(), cuerpo);
    }
}
