package com.demografia.controller;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Deja pasar al panel de administración solo a usuarios con sesión de servidor
 * iniciada y rol 1 (admin). La sesión se crea en UsuarioServlet (action=login),
 * por lo que no se puede falsificar desde el navegador editando localStorage.
 */
@WebFilter(urlPatterns = { "/admin.html", "/admin.js", "/admin.css", "/admin/*" })
public class AdminFilter implements Filter {

    public static boolean esAdmin(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s == null) return false;
        Object rol = s.getAttribute("id_rol");
        return rol instanceof Integer && ((Integer) rol) == 1;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        if (esAdmin(req)) {
            resp.setHeader("Cache-Control", "no-store");
            chain.doFilter(request, response);
            return;
        }

        boolean logueado = req.getSession(false) != null && req.getSession(false).getAttribute("id_rol") != null;
        String ruta = req.getRequestURI().substring(req.getContextPath().length());

        if (ruta.startsWith("/admin/")) {
            // llamadas de la API: respuesta JSON
            resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
            resp.setContentType("application/json");
            resp.setCharacterEncoding("UTF-8");
            resp.getWriter().write("{\"error\":\"Acceso solo para administradores\"}");
        } else if (logueado) {
            // usuario común intentando entrar al panel
            resp.sendRedirect(req.getContextPath() + "/principal.html");
        } else {
            resp.sendRedirect(req.getContextPath() + "/login.html?next=admin.html");
        }
    }
}
