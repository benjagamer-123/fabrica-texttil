package com.demografia.controller;

import java.io.IOException;   
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.demografia.model.Usuario;
import com.demografia.dao.interfaces.IUsuario;
import com.demografia.factory.factory;
import com.fasterxml.jackson.databind.ObjectMapper;
 

@WebServlet("/usuario")
public class UsuarioServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 // Interceptor unificado para CORS, OPTIONS y PATCH
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. Cabeceras CORS obligatorias
        resp.setHeader("Access-Control-Allow-Origin", "*");
        resp.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
        resp.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

        // 2. Responder automáticamente a la petición previa OPTIONS del navegador
        if ("OPTIONS".equalsIgnoreCase(req.getMethod())) {
            resp.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        // 3. Manejo de PATCH o delegar a los demás verbos (GET, POST, PUT, DELETE)
        if ("PATCH".equalsIgnoreCase(req.getMethod())) {
            doPatch(req, resp);
        } else {
            super.service(req, resp);
        }
    }
    // Mantenemos la factoría que venimos usando en el proyecto, o podés usar new UsuarioDAOImpl() si preferís
    private IUsuario dao = factory.getUsuarioDao();
    private ObjectMapper mapper = new ObjectMapper(); 

   
    
    // --- MÉTODO GET: PARA CONSULTAR (list o find) ---
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json"); 
        resp.setCharacterEncoding("UTF-8");
        
        String action = req.getParameter("action");
        
        switch (action != null ? action.toLowerCase() : "") {
            case "list":
                List<Usuario> usuarios = dao.listarTodos();
                for (Usuario u : usuarios) u.setPassword_hash(null);
                resp.getWriter().write(mapper.writeValueAsString(usuarios));
                break;
                
            case "find":
                String idParam = req.getParameter("id");
                if (idParam != null) {
                    int id = Integer.parseInt(idParam);
                    Usuario usuario = dao.obtenerPorId(id);
                    if (usuario != null) {
                        usuario.setPassword_hash(null);
                        resp.getWriter().write(mapper.writeValueAsString(usuario));
                    } else {
                        resp.getWriter().write("{\"message\":\"Usuario no encontrado\"}");
                    }
                } else {
                    resp.getWriter().write("{\"message\":\"ID requerido\"}");
                }
                break;
                
            default:
                resp.getWriter().write("{\"message\":\"Acción GET no válida\"}");
                break;
        }
    }

    // --- MÉTODO POST: PARA ESCRIBIR / REGISTRAR (add) ---
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String action = req.getParameter("action");
        
        switch (action != null ? action.toLowerCase() : "") {
        case "add":
            String nombre = req.getParameter("nombre");
            String email = req.getParameter("email");
            // Acepta tanto password_hash como password por seguridad
            String password = req.getParameter("password_hash");
            if (password == null || password.isEmpty()) {
                password = req.getParameter("password");
            }
            String estadoParam = req.getParameter("estado");
            String idRolParam = req.getParameter("id_rol");
                
                if (nombre != null && !nombre.isEmpty() && email != null && password != null) {
                    for (Usuario u : dao.listarTodos()) {
                        if (email.equalsIgnoreCase(u.getEmail())) {
                            resp.getWriter().write("{\"success\":false,\"message\":\"Ese correo ya está registrado\"}");
                            return;
                        }
                    }
                    Usuario nuevoUsuario = new Usuario();
                    nuevoUsuario.setNombre(nombre);
                    nuevoUsuario.setEmail(email);
                    nuevoUsuario.setPassword_hash(password);
                    nuevoUsuario.setEstado(estadoParam != null ? estadoParam : "Activo");
                    nuevoUsuario.setId_rol(idRolParam != null ? Integer.parseInt(idRolParam) : 1);
                    
                    boolean added = dao.registrar(nuevoUsuario);
                    resp.getWriter().write("{\"success\":" + added + "}");
                } else {
                    resp.getWriter().write("{\"message\":\"Campos obligatorios faltantes (nombre, email y password son requeridos)\"}");
                }
                break;
                
            case "login":
                String emailLogin = req.getParameter("email");
                String passLogin = req.getParameter("password");
                if (emailLogin != null && passLogin != null) {
                    for (Usuario u : dao.listarTodos()) {
                        if (emailLogin.equalsIgnoreCase(u.getEmail())
                                && passLogin.equals(u.getPassword_hash())
                                && !"Inactivo".equalsIgnoreCase(u.getEstado())) {
                            Usuario seguro = new Usuario();
                            seguro.setId_usuario(u.getId_usuario());
                            seguro.setNombre(u.getNombre());
                            seguro.setEmail(u.getEmail());
                            seguro.setEstado(u.getEstado());
                            seguro.setId_rol(u.getId_rol());
                            seguro.setPassword_hash(null);

                            // Sesión de servidor: es lo que valida el acceso al panel admin (rol 1)
                            HttpSession anterior = req.getSession(false);
                            if (anterior != null) anterior.invalidate();
                            HttpSession sesion = req.getSession(true);
                            sesion.setAttribute("id_usuario", u.getId_usuario());
                            sesion.setAttribute("id_rol", u.getId_rol());

                            resp.getWriter().write("{\"success\":true,\"usuario\":" + mapper.writeValueAsString(seguro) + "}");
                            return;
                        }
                    }
                }
                resp.getWriter().write("{\"success\":false,\"message\":\"Correo o contraseña incorrectos\"}");
                break;

            case "logout":
                HttpSession actual = req.getSession(false);
                if (actual != null) actual.invalidate();
                resp.getWriter().write("{\"success\":true}");
                break;

            default:
                resp.getWriter().write("{\"message\":\"Acción POST no válida\"}");
                break;
        }
    }

    // --- MÉTODO PUT: PARA ACTUALIZAR ---
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            int id = Integer.parseInt(idParam);
            Usuario usuario = dao.obtenerPorId(id);
            if (usuario != null) {
                String nombre = req.getParameter("nombre");
                String email = req.getParameter("email");
                String password = req.getParameter("password");
                String estadoParam = req.getParameter("estado");
                String idRolParam = req.getParameter("id_rol");
                
                if (nombre != null) usuario.setNombre(nombre);
                if (email != null) usuario.setEmail(email);
                if (password != null) usuario.setPassword_hash(password);
                if (estadoParam != null) usuario.setEstado(estadoParam);
                if (idRolParam != null) usuario.setId_rol(Integer.parseInt(idRolParam));
                
                dao.modificar(usuario);
                resp.getWriter().write("{\"success\":true, \"message\":\"Usuario actualizado exitosamente\"}");
            } else {
                resp.getWriter().write("{\"success\":false, \"message\":\"Usuario no encontrado\"}");
            }
        } else {
            resp.getWriter().write("{\"message\":\"ID requerido para actualizar\"}");
        }
    }

    // --- MÉTODO DELETE: PARA ELIMINAR ---
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            int id = Integer.parseInt(idParam);
            dao.eliminar(id);
            resp.getWriter().write("{\"success\":true, \"message\":\"Usuario eliminado exitosamente\"}");
        } else {
            resp.getWriter().write("{\"success\":false, \"message\":\"ID requerido para eliminar\"}");
        }
    }

    // --- MÉTODO PATCH: PARA ACTUALIZACIÓN PARCIAL (Ej: cambiar estado) ---
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        String estadoParam = req.getParameter("estado");
        
        if (idParam != null) {
            int id = Integer.parseInt(idParam);
            Usuario usuario = dao.obtenerPorId(id);
            if (usuario != null) {
                if (estadoParam != null) {
                    usuario.setEstado(estadoParam);
                    dao.modificar(usuario);
                    resp.getWriter().write("{\"success\":true, \"message\":\"Estado de usuario actualizado parcialmente\"}");
                } else {
                    resp.getWriter().write("{\"success\":false, \"message\":\"Parámetro estado requerido para PATCH\"}");
                }
            } else {
                resp.getWriter().write("{\"success\":false, \"message\":\"Usuario no encontrado\"}");
            }
        } else {
            resp.getWriter().write("{\"success\":false, \"message\":\"ID requerido para PATCH\"}");
        }
    }
}
