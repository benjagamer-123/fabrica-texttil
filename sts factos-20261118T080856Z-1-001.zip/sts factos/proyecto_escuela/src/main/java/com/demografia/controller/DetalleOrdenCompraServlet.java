package com.demografia.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.demografia.dao.interfaces.IDetalleOrdenCompra;
import com.demografia.factory.factory;
import com.demografia.model.DetalleOrdenCompra;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebServlet("/detalleordencompra")
public class DetalleOrdenCompraServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Instanciación limpia aplicando el Patrón Factory
    private IDetalleOrdenCompra dao = factory.getDetalleOrdenCompraDao();
    private ObjectMapper mapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        String action = req.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action.toLowerCase()) {
            case "buscar":
                String idStr = req.getParameter("id");
                if (idStr != null) {
                    // Ajustado al método listById del DAO
                    DetalleOrdenCompra doc = dao.listById(Integer.parseInt(idStr));
                    resp.getWriter().write(mapper.writeValueAsString(doc));
                }
                break;
            case "list":
            default:
                // Ajustado al método listAll del DAO
                List<DetalleOrdenCompra> lista = dao.listAll();
                resp.getWriter().write(mapper.writeValueAsString(lista));
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        try {
            DetalleOrdenCompra doc = mapper.readValue(req.getReader(), DetalleOrdenCompra.class);
            // Ajustado al método insert del DAO (lanza SQLException en la interfaz)
            dao.insert(doc);
            resp.getWriter().write("{\"mensaje\": \"Detalle de orden de compra registrado exitosamente\"}");
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\": \"" + e.getMessage() + "\"}");
        }
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        DetalleOrdenCompra doc = mapper.readValue(req.getReader(), DetalleOrdenCompra.class);
        // Ajustado al método update del DAO
        dao.update(doc);
        resp.getWriter().write("{\"mensaje\": \"Detalle de orden de compra actualizado exitosamente\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        String idStr = req.getParameter("id");
        if (idStr != null) {
            // Ajustado al método delete del DAO
            dao.delete(Integer.parseInt(idStr));
            resp.getWriter().write("{\"mensaje\": \"Detalle de orden de compra eliminado exitosamente\"}");
        } else {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"Se requiere el parámetro id\"}");
        }
    }
}