package com.demografia.factory;

import com.demografia.dao.implementaciones.*;
import com.demografia.dao.interfaces.*;

public class factory {

    public static IUsuario getUsuarioDao() {
        return new UsuarioDAOImpl();
    }

    public static IAuditoria getAuditoriaDao() {
        return new AuditoriaDAOImpl();
    }

    public static ICategoriaProducto getCategoriaProductoDao() {
        return new CategoriaProductoDAOImpl();
    }

    public static ICliente getClienteDao() {
        return new ClienteDAOImpl();
    }

    public static IConsumoMateriaPrima getConsumoMateriaPrimaDao() {
        return new ConsumoMateriaPrimaDAOImpl();
    }

    public static IDeposito getDepositoDao() {
        return new DepositoDAOImpl();
    }

    public static IDespacho getDespachoDao() {
        return new DespachoDAOImpl();
    }

    public static IDetalleDespacho getDetalleDespachoDao() {
        return new DetalleDespachoDAOImpl();
    }

    public static IDetalleOrdenCompra getDetalleOrdenCompraDao() {
        return new DetalleOrdenCompraDAOImpl();
    }

    public static IDetalleOrdenProd getDetalleOrdenProdDao() {
        return new DetalleOrdenProdDAOImpl();
    }

    public static IDetallePedido getDetallePedidoDao() {
        return new DetallePedidoDAOImpl();
    }


    public static IInventario getInventarioDao() {
        return new InventarioDAOImpl();
    }

    public static ILote getLoteDao() {
        return new LoteDAOImpl();
    }

    public static IMateriaPrima getMateriaPrimaDao() {
        return new MateriaPrimaDAOImpl();
    }

    public static IOrdenCompra getOrdenCompraDao() {
        return new OrdenCompraDAOImpl();
    }

    public static IOrdenProduccion getOrdenProduccionDao() {
        return new OrdenProduccionDAOImpl();
    }

    public static IPais getPaisDao() {
        return new PaisDAOImpl();
    }

    public static IPedido getPedidoDao() {
        return new PedidoDAOImpl();
    }

    public static IPermiso getPermisoDao() {
        return new PermisoDAOImpl();
    }

    public static IProducto getProductoDao() {
        return new ProductoDAOImpl();
    }

    public static IRol getRolDao() {
        return new RolDAOImpl();
    }
    
    public static IRedRelacion getRedRelacionDao() {
        return new RedRelacionDAOImpl();
    }
    
    public static IEtapaProduccion getEtapaProduccionDao() {
        return new EtapaProduccionDAOImpl();
    }
    
    public static IRedRolPermiso getRedRolPermisoDao() {
        return new RedRolPermisoDAOImpl();
    }
    
    public static IProveedor getProveedorDao() {
        return new ProveedorDAOImpl();
    }
}