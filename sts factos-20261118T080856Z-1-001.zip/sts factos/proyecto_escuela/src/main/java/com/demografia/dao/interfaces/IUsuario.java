package com.demografia.dao.interfaces;

import com.demografia.model.Usuario;


import java.util.List;


public interface IUsuario {
    boolean registrar(Usuario usuario);
    void modificar(Usuario usuario);
    void eliminar(Integer id);
    Usuario obtenerPorId(Integer id);
    List<Usuario> listarTodos();
}
