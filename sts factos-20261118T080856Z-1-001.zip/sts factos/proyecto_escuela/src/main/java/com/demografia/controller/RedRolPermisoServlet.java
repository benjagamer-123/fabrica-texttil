package com.demografia.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.demografia.dao.interfaces.IRedRolPermiso;
import com.demografia.factory.factory;
import com.demografia.model.RedRolPermiso;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebServlet("/redrolpermiso")
public class RedRolPermisoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private IRedRolPermiso dao = factory.getRedRolPermisoDao();
    private ObjectMapper mapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        String action = req.getParameter("action");
        if (action == null) action = "list";

        switch (action.toLowerCase()) {
            case "buscar":
                String idStr = req.getParameter("id");
                if (idStr != null) {
                    RedRolPermiso rrp = dao.obtenerPorId(Integer.parseInt(idStr));
                    resp.getWriter().write(mapper.writeValueAsString(rrp));
                }
                break;
            case "list":
            default:
                List<RedRolPermiso> lista = dao.listarTodos();
                resp.getWriter().write(mapper.writeValueAsString(lista));
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        RedRolPermiso rrp = mapper.readValue(req.getReader(), RedRolPermiso.class);
        dao.registrar(rrp);
        resp.getWriter().write("{\"mensaje\": \"Asociación rol-permiso registrada exitosamente\"}");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        RedRolPermiso rrp = mapper.readValue(req.getReader(), RedRolPermiso.class);
        dao.modificar(rrp);
        resp.getWriter().write("{\"mensaje\": \"Asociación rol-permiso actualizada exitosamente\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String idStr = req.getParameter("id");
        if (idStr != null) {
            dao.eliminar(Integer.parseInt(idStr));
            resp.getWriter().write("{\"mensaje\": \"Asociación rol-permiso eliminada exitosamente\"}");
        } else {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"Se requiere el parámetro id\"}");
        }
    }
}