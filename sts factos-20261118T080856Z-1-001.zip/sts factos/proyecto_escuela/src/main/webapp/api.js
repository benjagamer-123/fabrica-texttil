// ===== Capa de conexión con las APIs (servlets) de Banda de TL =====
// Las páginas se sirven desde el mismo Tomcat (/proyecto_escuela), por eso las URLs son relativas y no hace falta CORS.
const API = {
    usuario: 'usuario',
    producto: 'producto',
    pedido: 'pedido',
    detalle: 'detallepedido',
    cliente: 'cliente',
    pais: 'pais'
};

async function apiFetch(url, opciones = {}) {
    const resp = await fetch(url, opciones);
    const texto = await resp.text();
    let data = null;
    try { data = texto ? JSON.parse(texto) : null; } catch (e) { /* respuesta no JSON */ }
    if (!resp.ok) {
        throw new Error((data && (data.error || data.message)) || `Error ${resp.status} en ${url}`);
    }
    if (data === null) throw new Error(`Respuesta inválida del servidor en ${url}`);
    return data;
}

const apiGet = (url) => apiFetch(url);
const apiPostJson = (url, obj) => apiFetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(obj)
});
const apiPostForm = (url, obj) => apiFetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
    body: new URLSearchParams(obj).toString()
});

// ---------- sesión ----------
function obtenerSesion() {
    try { return JSON.parse(localStorage.getItem('usuarioBandaTL')); } catch (e) { return null; }
}
function guardarSesion(u) { localStorage.setItem('usuarioBandaTL', JSON.stringify(u)); }
function cerrarSesion() {
    localStorage.removeItem('usuarioBandaTL');
    // también cierra la sesión del servidor (la que habilita el panel admin)
    fetch(API.usuario + '?action=logout', { method: 'POST' })
        .catch(() => {})
        .finally(() => { window.location.href = 'login.html'; });
}

// cambia "Iniciar sesión" por el nombre del usuario + "Salir"
function actualizarNavSesion() {
    const u = obtenerSesion();
    document.querySelectorAll('a.btn-nav').forEach(a => {
        if (!u) return;
        a.textContent = `Salir (${u.nombre.split(' ')[0]})`;
        a.setAttribute('href', '#');
        a.addEventListener('click', (e) => { e.preventDefault(); cerrarSesion(); });
    });
}
document.addEventListener('DOMContentLoaded', actualizarNavSesion);

// ---------- catálogo ----------
// La tabla Producto no tiene precio ni imagen, así que se mantienen acá, asociados por nombre.
const META_TELAS = {
    algodon:    { precio: 12500, imagen: 'imagenes/algodon.jpg',    desc: 'Suave, transpirable y versátil. Ideal para prendas de uso diario.' },
    lino:       { precio: 15000, imagen: 'imagenes/lino.jpg',       desc: 'Fresco y ligero, perfecto para indumentaria de verano y alta costura.' },
    lana:       { precio: 18200, imagen: 'imagenes/lana.jpg',       desc: 'Excelente aislante térmico, ideal para abrigos y sacos de invierno.' },
    seda:       { precio: 24000, imagen: 'imagenes/seda.jpg',       desc: 'Textura suave y brillante, referente de elegancia y sofisticación.' },
    jean:       { precio: 14800, imagen: 'imagenes/jean.jpg',       desc: 'Resistente y duradero, el estándar para pantalones y camperas.' },
    terciopelo: { precio: 20500, imagen: 'imagenes/terciopelo.jpg', desc: 'Tejido de tacto suntuoso y elegante apariencia sobria.' },
    nailon:     { precio: 9500,  imagen: 'imagenes/nailon.jpg',     desc: 'Fibra sintética elástica y de alta resistencia al desgaste.' },
    poliester:  { precio: 8200,  imagen: 'imagenes/poliester.jpg',  desc: 'Económico, liviano y resistente a las arrugas y la humedad.' },
    jaba:       { precio: 7000,  imagen: 'imagenes/java.jpg',       desc: 'Material rústico y resistente, ideal para sacos y decoración.' },
    gabardina:  { precio: 13900, imagen: 'imagenes/gabardina.jpg',  desc: 'Tejido apretado y firme, idóneo para pilotos y pantalones de trabajo.' }
};

function normalizar(s) {
    return (s || '').toString().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
}
function buscarMeta(nombre) {
    const n = normalizar(nombre).replace('java', 'jaba');
    const clave = Object.keys(META_TELAS).find(k => n.includes(k));
    return clave ? META_TELAS[clave] : null;
}
// busca el producto de la BD que corresponde a un ítem del carrito (por nombre)
function buscarProductoPorNombre(productos, nombre) {
    const n = normalizar(nombre).replace('java', 'jaba');
    return productos.find(p => {
        const pn = normalizar(p.nombre).replace('java', 'jaba');
        return pn === n || pn.includes(n) || n.includes(pn);
    });
}

// muestra el enlace al panel solo si el usuario tiene rol 1
function agregarLinkAdmin() {
    const u = obtenerSesion();
    if (!u || Number(u.id_rol ?? u.rol) !== 1) return;
    const ul = document.querySelector('header nav ul');
    if (!ul || ul.querySelector('.link-admin')) return;
    const li = document.createElement('li');
    li.innerHTML = '<a href="admin.html" class="link-admin">Admin</a>';
    ul.prepend(li);
}
document.addEventListener('DOMContentLoaded', agregarLinkAdmin);