document.getElementById('form-login').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    btn.disabled = true;
    try {
        // Usamos API.usuario por prolijidad y consistencia con register.js
        const r = await apiPostForm(API.usuario + '?action=login', {
            email: document.getElementById('email').value.trim(),
            password: document.getElementById('password').value
        });
        if (r.success) {
            guardarSesion(r.usuario);
            const rol = Number(r.usuario.id_rol ?? r.usuario.rol);
            const next = new URLSearchParams(location.search).get('next');
            if (rol === 1) {
                // admin: va al panel (o a donde venía)
                window.location.href = next || 'admin.html';
            } else {
                // usuario común: nunca se lo manda al panel
                window.location.href = (next && !next.startsWith('admin')) ? next : 'principal.html';
            }
        } else {
            alert(r.message || 'Correo o contraseña incorrectos.');
        }
    } catch (err) {
        alert('No se pudo iniciar sesión: ' + err.message);
    } finally {
        btn.disabled = false;
    }
});
