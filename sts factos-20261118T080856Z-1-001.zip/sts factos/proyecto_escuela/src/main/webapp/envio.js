// interfaz y calculo de envio por porcentaje
document.addEventListener('DOMContentLoaded', () => {
    inicializarPantallaEnvio();
});

// obtiene el estado del carrito
function obtenerCarrito() {
    return JSON.parse(localStorage.getItem('carritoBandaTL')) || [];
}

function inicializarPantallaEnvio() {
    const selectorPais = document.getElementById('envio-pais');
    const inputCiudad = document.getElementById('envio-ciudad');
    const costoEnvioDisplay = document.getElementById('envio-costo-dinamico');
    const subtotalDisplay = document.getElementById('envio-subtotal-telas');
    const totalDisplay = document.getElementById('envio-total-final');
    const ivaDisplay = document.getElementById('envio-iva');
    const formulario = document.getElementById('form-datos-envio');
    
    const carrito = obtenerCarrito();
    
    // calculo del valor base de las telas acumuladas
    const subtotalTelas = carrito.reduce((acc, item) => acc + (item.precio * item.metros), 0);
    
    // muestra inicial de los importes base en la tarjeta resumen de la derecha
    subtotalDisplay.textContent = `$${subtotalTelas.toLocaleString('es-AR')}`;
    totalDisplay.textContent = `$${subtotalTelas.toLocaleString('es-AR')}`;
    
    let costoEnvioCalculado = 0;

    // incremento segun distancia internacional
    function calcularTasaLogistica() {
        const pais = selectorPais.value;
        const ciudadText = inputCiudad.value.trim().toLowerCase();
        
        if (!pais) {
            costoEnvioDisplay.textContent = "Seleccioná país...";
            costoEnvioDisplay.style.color = "#8c6d58";
            return;
        }

        // criterio por distancia (incrementos del 5 por ciento)
        let porcentajeTasa = 0.15; // 15% base general para argentina
        
        switch (pais) {
            case 'AR':
                if (ciudadText.includes('buenos aires') || ciudadText.includes('capital') || ciudadText.includes('caba')) {

                    porcentajeTasa = subtotalTelas >= 30000 ? 0 : 0.15;
                } else {
                    porcentajeTasa = 0.15;
                }
                break;
            case 'UY': // uruguay (+5%)
                porcentajeTasa = 0.20;
                break;
            case 'CL': // chile (+10%)
                porcentajeTasa = 0.25;
                break;
            case 'BR': // brasil (+15%)
                porcentajeTasa = 0.30;
                break;
            case 'US': // estados unidos (+20%)
                porcentajeTasa = 0.35;
                break;
            case 'ES': // españa (+25%)
                porcentajeTasa = 0.40;
                break;
            case 'ZA': // sudafrica (+30%)
                porcentajeTasa = 0.45;
                break;
            case 'CN': // china (+35%)
                porcentajeTasa = 0.50;
                break;
            default:
                porcentajeTasa = 0.25;
        }

        // calculo exacto multiplicando las telas por el porcentaje
        costoEnvioCalculado = Math.round(subtotalTelas * porcentajeTasa);
        
        // calculo definitivo del 21 por ciento de iva sobre los productos
        const ivaCalculado = Math.round(subtotalTelas * 0.21);
        if (ivaDisplay) {
            ivaDisplay.textContent = `$${ivaCalculado.toLocaleString('es-AR')}`;
        }

        if (costoEnvioCalculado === 0 && pais === 'AR') {
            costoEnvioDisplay.textContent = 'Gratis';
            costoEnvioDisplay.style.color = '#4f772d';
        } else {
            costoEnvioDisplay.textContent = `$${costoEnvioCalculado.toLocaleString('es-AR')} (${Math.round(porcentajeTasa * 100)}%)`;
            costoEnvioDisplay.style.color = '#5c4033';
        }

        // precio final: sumamos telas + encio + iva
        const totalFinal = subtotalTelas + costoEnvioCalculado + ivaCalculado;
        totalDisplay.textContent = `$${totalFinal.toLocaleString('es-AR')}`;
    }

    selectorPais.addEventListener('change', calcularTasaLogistica);
    inputCiudad.addEventListener('input', calcularTasaLogistica);

    formulario.addEventListener('submit', (e) => {
        e.preventDefault();
        
        if (selectorPais.value === "") {
            alert('Por favor, seleccioná un país de destino.');
            return;
        }

        const datosLogistica = {
            costoEnvio: costoEnvioCalculado,
            pais: selectorPais.options[selectorPais.selectedIndex].text,
            ciudad: inputCiudad.value,
            codigoPais: selectorPais.value,
            cp: document.getElementById('envio-cp').value,
            direccion: document.getElementById('envio-direccion').value,
            depto: document.getElementById('envio-depto').value
        };
       
        localStorage.setItem('datosEnvioBandaTL', JSON.stringify(datosLogistica));
        
        // avanzar directamente a la pantalla de la caja de pago
        window.location.href = 'pago.html';
    });
}
