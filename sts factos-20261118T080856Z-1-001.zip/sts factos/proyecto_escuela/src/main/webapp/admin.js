// ===== Panel de administración — Banda de TL =====
// Habla con /admin/api (AdminApiServlet). El acceso lo controla el servidor (AdminFilter, rol 1).
const API_ADMIN = 'admin/api';
const POR_PAGINA = 15;

const estado = {
    tablas: [],
    tabla: null,
    esquema: null,
    filas: [],
    filtradas: [],
    pagina: 1,
    editando: null,        // fila que se edita (null = nuevo registro)
    borrando: null,        // fila pendiente de eliminar
    fkCache: {}
};

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ---------- comunicación ----------
async function llamar(params, cuerpo) {
    const url = API_ADMIN + '?' + new URLSearchParams(params);
    const opts = cuerpo
        ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo) }
        : {};
    const r = await fetch(url, opts);
    if (r.status === 401 || r.status === 403) {
        window.location.href = 'login.html?next=admin.html';
        throw new Error('Sin permiso');
    }
    const texto = await r.text();
    let data;
    try { data = JSON.parse(texto); } catch (e) { throw new Error('Respuesta inválida del servidor'); }
    if (!r.ok || data.error) throw new Error(data.error || ('Error ' + r.status));
    return data;
}

function toast(msg, esError) {
    const t = $('toast');
    t.textContent = msg;
    t.className = 'toast' + (esError ? ' error-toast' : '');
    t.hidden = false;
    clearTimeout(toast.t);
    toast.t = setTimeout(() => { t.hidden = true; }, 3200);
}

// ---------- tipos de columna ----------
const tipoUp = (c) => (c.type || '').toUpperCase();
const esNumero = (c) => /INT|DECIMAL|NUMERIC|FLOAT|DOUBLE|YEAR/.test(tipoUp(c)) && !/^BIT/.test(tipoUp(c));
const esDecimal = (c) => /DECIMAL|NUMERIC|FLOAT|DOUBLE/.test(tipoUp(c));
const esFechaHora = (c) => /DATETIME|TIMESTAMP/.test(tipoUp(c));
const esFecha = (c) => tipoUp(c) === 'DATE';
const esTextoLargo = (c) => /TEXT/.test(tipoUp(c)) || c.size > 255;
const esBit = (c) => tipoUp(c).startsWith('BIT');

function valorParaMostrar(col, v) {
    if (v === null || v === undefined) return null;
    if (esBit(col)) return (v === 'true' || v === '1') ? '1' : '0';
    return v;
}

function valorParaInput(col, v) {
    if (v === null || v === undefined) return '';
    if (esFechaHora(col)) return String(v).replace(' ', 'T').slice(0, 19);
    if (esBit(col)) return (v === 'true' || v === '1') ? '1' : '0';
    return String(v);
}

function valorDesdeInput(col, v) {
    if (v === '') return '';
    if (esFechaHora(col)) return v.replace('T', ' ').length === 16 ? v.replace('T', ' ') + ':00' : v.replace('T', ' ');
    return v;
}

// ---------- carga inicial ----------
async function iniciar() {
    const u = obtenerSesion();
    $('usuario-actual').textContent = u ? u.nombre : '';
    $('btn-salir').addEventListener('click', cerrarSesion);

    try {
        estado.tablas = await llamar({ action: 'tables' });
    } catch (e) {
        toast(e.message, true);
        return;
    }
    const ul = $('lista-tablas');
    ul.innerHTML = estado.tablas.map(t => `<li><button type="button" data-tabla="${esc(t)}">${esc(t)}</button></li>`).join('');
    ul.addEventListener('click', (ev) => {
        const b = ev.target.closest('button[data-tabla]');
        if (b) abrirTabla(b.dataset.tabla);
    });

    $('buscar').addEventListener('input', () => { estado.pagina = 1; filtrar(); });
    $('btn-recargar').addEventListener('click', () => cargarFilas());
    $('btn-nuevo').addEventListener('click', () => abrirFormulario(null));
    $('pag-ant').addEventListener('click', () => { estado.pagina--; dibujarTabla(); });
    $('pag-sig').addEventListener('click', () => { estado.pagina++; dibujarTabla(); });

    $('form-cancelar').addEventListener('click', cerrarFormulario);
    $('form-registro').addEventListener('submit', guardarFormulario);
    $('borrar-cancelar').addEventListener('click', () => { $('modal-borrar').hidden = true; });
    $('borrar-ok').addEventListener('click', confirmarBorrado);
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { cerrarFormulario(); $('modal-borrar').hidden = true; }
    });

    // abre "usuario" por defecto si existe, si no la primera
    const inicial = estado.tablas.find(t => t.toLowerCase() === 'usuario') || estado.tablas[0];
    if (inicial) abrirTabla(inicial);
}

async function abrirTabla(nombre) {
    estado.tabla = nombre;
    estado.pagina = 1;
    $('buscar').value = '';
    document.querySelectorAll('#lista-tablas button').forEach(b => b.classList.toggle('activa', b.dataset.tabla === nombre));
    $('titulo-tabla').textContent = nombre;
    $('toolbar').hidden = false;
    try {
        estado.esquema = await llamar({ action: 'schema', table: nombre });
        await cargarFilas();
    } catch (e) { toast(e.message, true); }
}

async function cargarFilas() {
    const r = await llamar({ action: 'list', table: estado.tabla });
    estado.filas = r.rows;
    $('aviso-truncado').hidden = !r.truncated;
    filtrar();
}

function filtrar() {
    const q = $('buscar').value.trim().toLowerCase();
    estado.filtradas = !q ? estado.filas : estado.filas.filter(f =>
        Object.values(f).some(v => v !== null && String(v).toLowerCase().includes(q)));
    dibujarTabla();
}

// ---------- tabla ----------
function dibujarTabla() {
    const cols = estado.esquema.columns;
    const total = estado.filtradas.length;
    const paginas = Math.max(1, Math.ceil(total / POR_PAGINA));
    estado.pagina = Math.min(Math.max(1, estado.pagina), paginas);
    const desde = (estado.pagina - 1) * POR_PAGINA;
    const visibles = estado.filtradas.slice(desde, desde + POR_PAGINA);

    $('subtitulo').textContent = `${total} registro${total === 1 ? '' : 's'}` +
        (estado.esquema.pk.length ? '' : ' · tabla sin clave primaria (solo lectura / alta)');

    $('tabla').querySelector('thead').innerHTML =
        '<tr>' + cols.map(c => `<th>${esc(c.name)}</th>`).join('') + '<th></th></tr>';

    const editable = estado.esquema.pk.length > 0;
    $('tabla').querySelector('tbody').innerHTML = visibles.map((f, i) => {
        const celdas = cols.map(c => {
            const v = valorParaMostrar(c, f[c.name]);
            return v === null ? '<td class="null">null</td>' : `<td title="${esc(v)}">${esc(v)}</td>`;
        }).join('');
        const acc = editable
            ? `<td class="acciones"><button class="btn btn-sm" data-ed="${desde + i}">Editar</button><button class="btn btn-sm btn-danger" data-del="${desde + i}">Eliminar</button></td>`
            : '<td></td>';
        return `<tr>${celdas}${acc}</tr>`;
    }).join('');

    $('vacio').hidden = total > 0;
    $('paginacion').hidden = total <= POR_PAGINA;
    $('pag-info').textContent = `Página ${estado.pagina} de ${paginas}`;
    $('pag-ant').disabled = estado.pagina <= 1;
    $('pag-sig').disabled = estado.pagina >= paginas;
}

$('tabla').addEventListener('click', (ev) => {
    const ed = ev.target.closest('[data-ed]');
    const del = ev.target.closest('[data-del]');
    if (ed) abrirFormulario(estado.filtradas[Number(ed.dataset.ed)]);
    if (del) pedirBorrado(estado.filtradas[Number(del.dataset.del)]);
});

// ---------- opciones de claves foráneas ----------
async function opcionesFk(ref) {
    const clave = ref.table;
    if (!estado.fkCache[clave]) {
        const [esq, lista] = await Promise.all([
            llamar({ action: 'schema', table: ref.table }),
            llamar({ action: 'list', table: ref.table })
        ]);
        const colEtiqueta = esq.columns.find(c => !c.pk && !c.secret && /CHAR|TEXT/.test(tipoUp(c)));
        estado.fkCache[clave] = lista.rows.map(f => ({
            valor: f[ref.column],
            etiqueta: f[ref.column] + (colEtiqueta && f[colEtiqueta.name] ? ' · ' + f[colEtiqueta.name] : '')
        }));
    }
    return estado.fkCache[clave];
}

// ---------- formulario ----------
async function abrirFormulario(fila) {
    estado.editando = fila;
    const esq = estado.esquema;
    $('form-titulo').textContent = (fila ? 'Editar registro' : 'Nuevo registro') + ' — ' + estado.tabla;
    $('form-error').hidden = true;
    const cont = $('form-campos');
    cont.innerHTML = '';

    for (const c of esq.columns) {
        if (!fila && c.autoIncrement) continue;                 // lo genera la base
        const bloqueado = !!fila && (c.pk || c.autoIncrement);  // la clave no se edita
        const requerido = !c.nullable && !c.hasDefault && !c.autoIncrement && !(c.secret && fila);
        const valor = fila ? valorParaInput(c, fila[c.name]) : '';
        const id = 'f_' + c.name;

        let campo;
        const fk = esq.fks[c.name];
        if (fk) {
            let opts = [];
            try { opts = await opcionesFk(fk); } catch (e) { /* si falla, queda vacío */ }
            const tiene = opts.some(o => String(o.valor) === valor);
            campo = `<select id="${id}" ${bloqueado ? 'disabled' : ''}>` +
                (c.nullable || !valor ? '<option value="">— elegir —</option>' : '') +
                opts.map(o => `<option value="${esc(o.valor)}" ${String(o.valor) === valor ? 'selected' : ''}>${esc(o.etiqueta)}</option>`).join('') +
                (valor && !tiene ? `<option value="${esc(valor)}" selected>${esc(valor)}</option>` : '') +
                '</select>';
        } else if (esBit(c)) {
            campo = `<select id="${id}" ${bloqueado ? 'disabled' : ''}><option value="1" ${valor === '1' ? 'selected' : ''}>Sí</option><option value="0" ${valor !== '1' ? 'selected' : ''}>No</option></select>`;
        } else if (c.secret) {
            campo = `<input id="${id}" type="password" autocomplete="new-password" placeholder="${fila ? 'Dejar vacío para no cambiar' : ''}">`;
        } else if (esTextoLargo(c)) {
            campo = `<textarea id="${id}" ${bloqueado ? 'disabled' : ''}>${esc(valor)}</textarea>`;
        } else {
            let tipo = 'text', extra = '';
            if (esNumero(c)) { tipo = 'number'; extra = esDecimal(c) ? 'step="any"' : 'step="1"'; }
            else if (esFechaHora(c)) { tipo = 'datetime-local'; extra = 'step="1"'; }
            else if (esFecha(c)) tipo = 'date';
            else if (/email/i.test(c.name)) tipo = 'email';
            const max = tipo === 'text' && c.size ? `maxlength="${c.size}"` : '';
            campo = `<input id="${id}" type="${tipo}" ${extra} ${max} value="${esc(valor)}" ${bloqueado ? 'disabled' : ''}>`;
        }

        const nota = [c.pk ? 'clave' : '', requerido ? '' : 'opcional'].filter(Boolean).join(' · ');
        cont.insertAdjacentHTML('beforeend',
            `<div class="campo"><label for="${id}">${esc(c.name)} ${nota ? `<em>(${nota})</em>` : ''}</label>${campo}</div>`);
    }
    $('modal-form').hidden = false;
    const primero = cont.querySelector('input:not(:disabled), select:not(:disabled), textarea:not(:disabled)');
    if (primero) primero.focus();
}

function cerrarFormulario() { $('modal-form').hidden = true; }

async function guardarFormulario(ev) {
    ev.preventDefault();
    const esq = estado.esquema;
    const fila = estado.editando;
    const values = {};
    const faltan = [];

    for (const c of esq.columns) {
        const el = $('f_' + c.name);
        if (!el || el.disabled) continue;
        const v = valorDesdeInput(c, c.secret ? el.value : el.value.trim());
        const requerido = !c.nullable && !c.hasDefault && !c.autoIncrement && !(c.secret && fila);
        if (requerido && v === '') faltan.push(c.name);
        values[c.name] = v;
    }
    if (faltan.length) { mostrarErrorForm('Completá los campos obligatorios: ' + faltan.join(', ')); return; }

    const btn = $('form-guardar');
    btn.disabled = true;
    try {
        if (fila) {
            const pk = {};
            esq.pk.forEach(k => { pk[k] = fila[k]; });
            await llamar({ action: 'update', table: estado.tabla }, { pk, values });
            toast('Registro actualizado');
        } else {
            await llamar({ action: 'insert', table: estado.tabla }, { values });
            toast('Registro creado');
        }
        delete estado.fkCache[estado.tabla];
        cerrarFormulario();
        await cargarFilas();
    } catch (e) {
        mostrarErrorForm(e.message);
    } finally {
        btn.disabled = false;
    }
}

function mostrarErrorForm(msg) {
    const p = $('form-error');
    p.textContent = msg;
    p.hidden = false;
}

// ---------- eliminar ----------
function pedirBorrado(fila) {
    estado.borrando = fila;
    const clave = estado.esquema.pk.map(k => `${k} = ${fila[k]}`).join(', ');
    $('borrar-texto').textContent = `¿Seguro que querés eliminar el registro (${clave}) de ${estado.tabla}? Esta acción no se puede deshacer.`;
    $('borrar-error').hidden = true;
    $('modal-borrar').hidden = false;
}

async function confirmarBorrado() {
    const fila = estado.borrando;
    if (!fila) return;
    const pk = {};
    estado.esquema.pk.forEach(k => { pk[k] = fila[k]; });
    const btn = $('borrar-ok');
    btn.disabled = true;
    try {
        await llamar({ action: 'delete', table: estado.tabla }, { pk });
        $('modal-borrar').hidden = true;
        delete estado.fkCache[estado.tabla];
        toast('Registro eliminado');
        await cargarFilas();
    } catch (e) {
        const p = $('borrar-error');
        p.textContent = e.message;
        p.hidden = false;
    } finally {
        btn.disabled = false;
    }
}

document.addEventListener('DOMContentLoaded', iniciar);
