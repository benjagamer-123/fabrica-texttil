// config inicial
document.addEventListener('DOMContentLoaded', () => {
    // inicializamos los botones del catalogo en el index
    if (document.querySelector('.grid-telas')) {
        inicializarCatalogo();
    }
    if (document.querySelector('.carrito-productos')) {
        renderizarCarrito();
    }
});

// obtiene el carrito guardado en el storage
function obtenerCarrito() {
    return JSON.parse(localStorage.getItem('carritoBandaTL')) || [];
}

// guarda los cambios del carrito en el storage
function guardarCarrito(carrito) {
    localStorage.setItem('carritoBandaTL', JSON.stringify(carrito));
}

// logica del catalogo (index.html)
// intenta cargar los productos desde la API /producto; si falla o viene vacío, queda el catálogo estático del HTML
async function inicializarCatalogo() {
    try {
        const productos = await apiGet('producto?action=list');
        if (Array.isArray(productos) && productos.length > 0) {
            renderizarCatalogoAPI(productos);
        } else {
            mostrarAviso('La base de datos no tiene productos cargados: se muestra el catálogo local.');
        }
    } catch (err) {
        console.error(err);
        mostrarAviso('No se pudo conectar con el servidor: se muestra el catálogo local.');
    }
    enlazarBotonesCatalogo();
}

function mostrarAviso(texto) {
    const t = document.querySelector('.section-title');
    if (!t) return;
    const p = document.createElement('p');
    p.style.cssText = 'color:#a33; font-weight:600; margin-top:8px;';
    p.textContent = texto;
    t.appendChild(p);
}

function renderizarCatalogoAPI(productos) {
    const grid = document.querySelector('.grid-telas');
    grid.innerHTML = '';
    productos.forEach(p => {
        const meta = buscarMeta(p.nombre);
        const precio = meta ? meta.precio : null;
        const imagen = meta ? meta.imagen : 'imagenes/algodon.jpg';
        const desc = p.descripcion || (meta ? meta.desc : '');
        const card = document.createElement('div');
        card.className = 'tela-card';
        card.dataset.idProducto = p.id_producto;
        card.dataset.precio = precio === null ? '' : precio;
        card.innerHTML = `
            <div class="img-container"><img src="${imagen}" alt=""></div>
            <div class="tela-info">
                <h3></h3>
                <p class="desc"></p>
                <div class="card-footer-item">
                    <span class="precio">${precio === null ? 'Consultar' : '$' + precio.toLocaleString('es-AR') + ' / m'}</span>
                    <button class="btn-carrito" ${precio === null ? 'disabled' : ''}>Añadir al carrito</button>
                </div>
            </div>`;
        card.querySelector('img').alt = p.nombre;
        card.querySelector('h3').textContent = p.nombre;
        card.querySelector('.desc').textContent = desc;
        grid.appendChild(card);
    });
}

function enlazarBotonesCatalogo() {
    document.querySelectorAll('.btn-carrito').forEach(boton => {
        boton.addEventListener('click', (e) => {
            const card = e.target.closest('.tela-card');
            const titulo = card.querySelector('h3').textContent;
            const nombre = titulo.replace(/^\d+\.\s*/, '').trim();
            const precio = card.dataset.precio
                ? parseInt(card.dataset.precio, 10)
                : parseInt(card.querySelector('.precio').textContent.replace(/[^\d]/g, ''), 10);
            const imagen = card.querySelector('img').getAttribute('src');
            // id = id real de la BD si vino de la API; si no, el número del catálogo estático
            const id = card.dataset.idProducto || titulo.split('.')[0].trim();
            añadirAlCarrito({ id, nombre, precio, imagen, metros: 1 });
        });
    });
}

function añadirAlCarrito(productoNuevo) {
    let carrito = obtenerCarrito();
    const existe = carrito.find(item => item.id === productoNuevo.id);
    
    if (existe) {
        existe.metros += 1; 
    } else {
        carrito.push(productoNuevo); 
    }
    
    guardarCarrito(carrito);

    console.log(`producto añadido: ${productoNuevo.nombre}`);
    alert(`¡Añadiste 1 metro de ${productoNuevo.nombre} al carrito!`);
}

// logica de la vista del carrito (carrito.html)
function renderizarCarrito() {
    const contenedor = document.querySelector('.carrito-productos');
    const carrito = obtenerCarrito();
    
    if (carrito.length === 0) {
        contenedor.innerHTML = `
            <div class="item-carrito" style="justify-content: center; padding: 40px;">
                <p style="font-size: 18px; color: #8c6d58; font-weight: 600;">Tu carrito está vacío. ¡Explorá nuestro catálogo!</p>
            </div>
        `;
        actualizarTotales();
        return;
    }
    
    contenedor.innerHTML = ''; 

    carrito.forEach(producto => {
        const subtotalProducto = producto.precio * producto.metros;
        
        const itemHTML = `
            <div class="item-carrito" data-id="${producto.id}">
                <img src="${producto.imagen}" alt="${producto.nombre}" class="item-img">
                <div class="item-detalles">
                    <h3>${producto.id}. ${producto.nombre}</h3>
                    <p class="item-precio-unitario">Precio por metro: $${producto.precio.toLocaleString('es-AR')}</p>
                </div>
                <div class="item-cantidad">
                    <label>Metros:</label>
                    <input type="number" value="${producto.metros}" min="1" class="input-metros">
                </div>
                <div class="item-subtotal">
                    <span>$${subtotalProducto.toLocaleString('es-AR')}</span>
                </div>
                <button class="btn-eliminar" title="Eliminar producto">&times;</button>
            </div>
        `;
        contenedor.insertAdjacentHTML('beforeend', itemHTML);
    });

    asignarEventosCarrito();
    actualizarTotales();
}

function asignarEventosCarrito() {
    const inputsMetros = document.querySelectorAll('.input-metros');
    inputsMetros.forEach(input => {
        input.addEventListener('change', (e) => {
            const id = e.target.closest('.item-carrito').dataset.id;
            let nuevaCantidad = parseInt(e.target.value, 10);
            
            if (isNaN(nuevaCantidad) || nuevaCantidad < 1) {
                nuevaCantidad = 1;
                e.target.value = 1;
            }
            
            modificarMetros(id, nuevaCantidad);
        });
    });

    const botonesEliminar = document.querySelectorAll('.btn-eliminar');
    botonesEliminar.forEach(boton => {
        boton.addEventListener('click', (e) => {
            const id = e.target.closest('.item-carrito').dataset.id;
            eliminarProducto(id);
        });
    });
}

function modificarMetros(id, cantidad) {
    let carrito = obtenerCarrito();
    const producto = carrito.find(item => item.id === id);
    
    if (producto) {
        producto.metros = cantidad;
        guardarCarrito(carrito);
        renderizarCarrito();
    }
}

function eliminarProducto(id) {
    let carrito = obtenerCarrito();
    carrito = carrito.filter(item => item.id !== id);
    guardarCarrito(carrito);
    renderizarCarrito();
}

// calculo de los importes finales
function actualizarTotales() {
    const carrito = obtenerCarrito();
    const subtotalGeneral = carrito.reduce((acumulador, item) => acumulador + (item.precio * item.metros), 0);
    
    // guardamos los nodos de la vista por id
    const subtotalElemento = document.getElementById('carrito-subtotal');
    const ivaElemento = document.getElementById('carrito-iva');
    const totalElemento = document.getElementById('carrito-total');
    const saldoCarritoElemento = document.getElementById('saldo-carrito-monto');
    const btnPagoBloqueado = document.getElementById('btn-proceder-pago-bloqueado');
    
    // 1. ponemos el saldo disponible actual que viene de la billetera
    const saldoGuardado = localStorage.getItem('saldoBandaTL') || '0';
    if (saldoCarritoElemento) {
        saldoCarritoElemento.textContent = `$${parseInt(saldoGuardado, 10).toLocaleString('es-AR')}`;
    }
    
    // 2. calculamos el iva del 21 por ciento sobre el total de telas
    const ivaCalculado = Math.round(subtotalGeneral * 0.21);
    if (ivaElemento) {
        ivaElemento.textContent = `$${ivaCalculado.toLocaleString('es-AR')}`;
    }

    // 3. cargo el subtotal base
    if (subtotalElemento) {
        subtotalElemento.textContent = `$${subtotalGeneral.toLocaleString('es-AR')}`;
    }
    
    // 4. unimos el importe total final sumando el iva
    if (totalElemento) {
        const totalConIva = subtotalGeneral + ivaCalculado;
        totalElemento.textContent = `$${totalConIva.toLocaleString('es-AR')}`;
    }

    // 5. Hago que el botón de pago de logística se pueda bloquear
    if (btnPagoBloqueado && localStorage.getItem('datosEnvioBandaTL') && carrito.length > 0) {
        btnPagoBloqueado.style.opacity = '1';
        btnPagoBloqueado.style.cursor = 'pointer';
        btnPagoBloqueado.onclick = () => { window.location.href = 'pago.html'; };
    } else if (btnPagoBloqueado) {
        btnPagoBloqueado.onclick = () => {
            const cartel = document.getElementById('cartel-alerta-envio');
            if (cartel) {
                cartel.style.display = 'flex';
                window.scrollTo({ top: 0, behavior: 'smooth' }); 
            }
        };
    }
}
