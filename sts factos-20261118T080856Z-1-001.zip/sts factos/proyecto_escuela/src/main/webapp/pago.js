// procesamiento del pago 

// validamos el saldo inicial
if (localStorage.getItem('saldoBandaTL') === null) {
    localStorage.setItem('saldoBandaTL', '0');
}

document.addEventListener('DOMContentLoaded', () => {
    inicializarPantallaPago();
});

// obtiene el listado de productos seleccionados
function obtenerCarrito() {
    return JSON.parse(localStorage.getItem('carritoBandaTL')) || [];
}

function inicializarPantallaPago() {
    const contenedorTelas = document.getElementById('desglose-telas-pago');
    const saldoDisplay = document.getElementById('saldo-actual');
    const subtotalDisplay = document.getElementById('pago-subtotal');
    const totalDisplay = document.getElementById('pago-total');
    const envioDisplay = document.getElementById('pago-envio');
    const ivaDisplay = document.getElementById('pago-iva');
    const btnCargar = document.getElementById('btn-cargar-saldo');
    const btnPagar = document.getElementById('btn-confirmar-pago');
   
    const carrito = obtenerCarrito();
    let saldo = parseInt(localStorage.getItem('saldoBandaTL'), 10);

    // mostramos el saldo actual en la tarjeta
    saldoDisplay.textContent = `$${saldo.toLocaleString('es-AR')}`;


    if (btnCargar) {
        btnCargar.onclick = () => {
            const inputMonto = document.getElementById('monto-ingresar');
            const monto = parseInt(inputMonto.value, 10);

            if (isNaN(monto) || monto <= 0) {
                alert('Por favor, ingresa un monto valido mayor a 0.');
                return;
            }

            saldo += monto;
            localStorage.setItem('saldoBandaTL', saldo.toString());
            saldoDisplay.textContent = `$${saldo.toLocaleString('es-AR')}`;
            inputMonto.value = '';
            alert(`¡Carga exitosa! Se acreditaron $${monto.toLocaleString('es-AR')} en tu cuenta.`);
        };
    }


    if (carrito.length === 0) {
        if (contenedorTelas) {
            contenedorTelas.innerHTML = `<p style="color:#8c6d58; font-weight:600;">No hay productos seleccionados para pagar.</p>`;
        }
        if (subtotalDisplay) subtotalDisplay.textContent = `$0`;
        if (envioDisplay) envioDisplay.textContent = `$0`;
        if (ivaDisplay) ivaDisplay.textContent = `$0`;
        if (totalDisplay) totalDisplay.textContent = `$0`;
       
        if (btnPagar) {
            btnPagar.style.opacity = "0.5";
            btnPagar.style.cursor = "not-allowed";
            btnPagar.onclick = () => {
                alert('Tu carrito esta vacio. No hay ninguna orden para abonar.');
            };
        }
        return;
    }

    // si el carrito tiene productos, armamos el listado
    if (contenedorTelas) contenedorTelas.innerHTML = '';
    let subtotalGeneral = 0;

    carrito.forEach(item => {
        const totalItem = item.precio * item.metros;
        subtotalGeneral += totalItem;
        
        const itemPagoHTML = `
            <div class="detalle-item-pago">
                <div>
                    <span class="item-nombre">${item.nombre}</span>
                    <br>
                    <span class="item-metros">${item.metros} metros x $${item.precio.toLocaleString('es-AR')}</span>
                </div>
                <span style="font-weight:600; color:#4a3b32;">$${totalItem.toLocaleString('es-AR')}</span>
            </div>
        `;
        if (contenedorTelas) {
            contenedorTelas.insertAdjacentHTML('beforeend', itemPagoHTML);
        }
    });


    const logisticaGuardada = JSON.parse(localStorage.getItem('datosEnvioBandaTL')) || { costoEnvio: 0 };
    let costoEnvio = logisticaGuardada.costoEnvio;

    if (envioDisplay) {
        if (costoEnvio > 0) {
            envioDisplay.textContent = `$${costoEnvio.toLocaleString('es-AR')}`;
            envioDisplay.classList.remove('envio-gratis');
            envioDisplay.style.color = '#8c6d58';
        } else {
            envioDisplay.textContent = 'Gratis';
            envioDisplay.classList.add('envio-gratis');
            envioDisplay.style.color = '#4f772d';
        }
    }

    // calculo del 21 por ciento de iva sobre el subtotal acumulado
    const ivaCalculado = Math.round(subtotalGeneral * 0.21);
    if (ivaDisplay) {
        ivaDisplay.textContent = `$${ivaCalculado.toLocaleString('es-AR')}`;
    }

    // unimos el calculo final: productos + envio + iva
    const totalFinal = subtotalGeneral + costoEnvio + ivaCalculado;
    if (subtotalDisplay) subtotalDisplay.textContent = `$${subtotalGeneral.toLocaleString('es-AR')}`;
    if (totalDisplay) totalDisplay.textContent = `$${totalFinal.toLocaleString('es-AR')}`;

    // procesamiento y validacion de compra definitiva (guarda el pedido en la BD mediante las APIs)
    if (btnPagar) {
        btnPagar.onclick = async () => {
            const usuario = obtenerSesion();
            if (!usuario) {
                alert('Tenés que iniciar sesión para pagar.');
                window.location.href = 'login.html?next=pago.html';
                return;
            }
            if (saldo < totalFinal) {
                alert('Saldo insuficiente. Por favor, carga mas dinero en tu cuenta.');
                return;
            }
            btnPagar.disabled = true;
            try {
                const idPedido = await registrarPedidoEnServidor(usuario, carrito, logisticaGuardada, totalFinal);

                saldo -= totalFinal;
                localStorage.setItem('saldoBandaTL', saldo.toString());
                localStorage.setItem('carritoBandaTL', JSON.stringify([]));
                localStorage.removeItem('datosEnvioBandaTL');

                alert(`¡Pago procesado con éxito! Pedido Nº ${idPedido}. Gracias por tu compra en Banda de TL.`);
                window.location.href = 'principal.html';
            } catch (err) {
                console.error(err);
                alert('No se pudo registrar el pedido: ' + err.message + '\nNo se descontó ningún saldo.');
                btnPagar.disabled = false;
            }
        };
    }
}

// ---- integración con las APIs ----
async function asegurarPais(codigoIso, nombre) {
    const paises = await apiGet('pais?action=list');
    const iso3 = { AR:'ARG', BR:'BRA', CL:'CHL', UY:'URY', US:'USA', ES:'ESP', CN:'CHN', ZA:'ZAF' }[codigoIso];
    let p = paises.find(x => x.codigo_iso && [codigoIso, iso3].includes(x.codigo_iso.toUpperCase()))
         || paises.find(x => normalizar(x.nombre) === normalizar(nombre));
    if (p) return p.id_pais;
    await apiPostJson('pais', { nombre, codigo_iso: codigoIso });
    const nuevos = await apiGet('pais?action=list');
    p = nuevos.find(x => x.codigo_iso === codigoIso);
    if (!p) throw new Error('No se pudo registrar el país de destino.');
    return p.id_pais;
}

async function asegurarCliente(usuario, envio) {
    const clientes = await apiGet('cliente?action=list');
    const existente = clientes.find(c => c.email && c.email.toLowerCase() === usuario.email.toLowerCase());
    if (existente) return existente.id_cliente;
    const idPais = await asegurarPais(envio.codigoPais || 'AR', (envio.pais || 'Argentina').replace(/\s*\(.*\)/, ''));
    await apiPostJson('cliente', {
        razon_social: usuario.nombre,
        cuit: null,
        tipo_cliente: 'Minorista',
        email: usuario.email,
        telefono: '',
        direccion: envio.direccion || '',
        ciudad: envio.ciudad || '',
        id_pais: idPais,
        estado: 'Activo'
    });
    const despues = await apiGet('cliente?action=list');
    const nuevo = despues.find(c => c.email && c.email.toLowerCase() === usuario.email.toLowerCase());
    if (!nuevo) throw new Error('No se pudo crear el cliente.');
    return nuevo.id_cliente;
}

async function registrarPedidoEnServidor(usuario, carrito, envio, totalFinal) {
    // 1) resolver id_producto reales
    const productos = await apiGet('producto?action=list');
    const items = carrito.map(it => {
        const prod = buscarProductoPorNombre(productos, it.nombre);
        return { it, prod };
    });
    const faltantes = items.filter(x => !x.prod).map(x => x.it.nombre);
    if (faltantes.length) {
        throw new Error('Estos productos no existen en la base de datos: ' + faltantes.join(', '));
    }

    // 2) cliente (se crea si es la primera compra)
    const idCliente = await asegurarCliente(usuario, envio);

    // 3) cabecera del pedido
    const hoy = new Date();
    const entrega = new Date(hoy.getTime() + 7 * 86400000);
    const iso = d => d.toISOString().slice(0, 10);
    const obs = `Envío a ${envio.direccion || ''} ${envio.depto || ''}, ${envio.ciudad || ''} ${envio.cp || ''}, ${envio.pais || ''}. Costo de envío: $${envio.costoEnvio || 0}`;
    await apiPostJson('pedido', {
        id_cliente: idCliente,
        fecha_pedido: iso(hoy),
        estado: 'Pendiente',
        fecha_entrega_req: iso(entrega),
        observaciones: obs,
        total_estimado: totalFinal,
        id_producto: items[0].prod.id_producto
    });

    // el servlet no devuelve el id generado: tomamos el pedido más reciente del cliente
    const pedidos = await apiGet('pedido?action=list');
    const mios = pedidos.filter(p => p.id_cliente === idCliente);
    if (!mios.length) throw new Error('El pedido no quedó registrado.');
    const idPedido = Math.max(...mios.map(p => p.id_pedido));

    // 4) detalle por cada tela
    for (const { it, prod } of items) {
        await apiPostJson('detallepedido', {
            id_pedido: idPedido,
            id_producto: prod.id_producto,
            cantidad: it.metros,
            precio_unitario: it.precio,
            descuento: 0,
            subtotal: it.precio * it.metros
        });
    }
    return idPedido;
}
