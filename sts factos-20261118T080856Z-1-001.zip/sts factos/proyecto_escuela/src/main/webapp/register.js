document.getElementById('form-registro').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const pass = document.getElementById('password').value;
    if (pass !== document.getElementById('confirm-password').value) {
        alert('Las contraseñas no coinciden.');
        return;
    }
    
    const btn = e.target.querySelector('button[type=submit]');
    btn.disabled = true;
    
    try {
        const r = await apiPostForm(API.usuario + '?action=add', {
            nombre: document.getElementById('nombre').value.trim(),
            email: document.getElementById('email').value.trim(),
            password: pass,         // Enviamos 'password' por si el servlet lo busca así
            password_hash: pass,    // Enviamos 'password_hash' por si el servlet lo busca así
            estado: 'Activo',
            id_rol: '1'
        });
        
        if (r.success) {
            alert('¡Cuenta creada! Ahora podés iniciar sesión.');
            window.location.href = 'login.html';
        } else {
            alert(r.message || 'No se pudo crear la cuenta (¿el correo ya existe?).');
        }
    } catch (err) {
        alert('Error al registrarse: ' + err.message);
    } finally {
        btn.disabled = false;
    }
});